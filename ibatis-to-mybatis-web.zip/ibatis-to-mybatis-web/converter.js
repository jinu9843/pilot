(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.IbatisMybatisConverter = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  const MYBATIS_DOCTYPE =
    '<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "https://mybatis.org/dtd/mybatis-3-mapper.dtd">';

  function parseAttributes(attributeText) {
    const attributes = {};
    const regex = /([A-Za-z_:][\w:.-]*)\s*=\s*(['"])(.*?)\2/g;
    let match = regex.exec(attributeText || "");

    while (match) {
      attributes[match[1]] = match[3];
      match = regex.exec(attributeText || "");
    }

    return attributes;
  }

  function quoteLiteral(value) {
    if (value == null || value === "") {
      return "''";
    }

    if (/^-?\d+(\.\d+)?$/.test(value)) {
      return value;
    }

    if (/^(true|false|null)$/i.test(value)) {
      return value.toLowerCase();
    }

    return "'" + String(value).replace(/'/g, "\\'") + "'";
  }

  function buildIfTest(tagName, attrs) {
    const property = attrs.property;

    switch (tagName) {
      case "isParameterPresent":
        return "_parameter != null";
      case "isNotParameterPresent":
        return "_parameter == null";
      default:
        break;
    }

    if (!property) {
      return "";
    }

    switch (tagName) {
      case "isNotNull":
        return property + " != null";
      case "isNull":
        return property + " == null";
      case "isNotEmpty":
        return property + " != null and " + property + " != ''";
      case "isEmpty":
        return property + " == null or " + property + " == ''";
      case "isEqual":
        return property + " == " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isNotEqual":
        return property + " != " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isGreaterThan":
        return property + " > " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isGreaterEqual":
        return property + " >= " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isLessThan":
        return property + " < " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isLessEqual":
        return property + " <= " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      default:
        return "";
    }
  }

  function replaceDoctype(source) {
    const sqlMapDoctypeRegex = /<!DOCTYPE\s+(sqlMap|mapper)[\s\S]*?>/i;

    if (sqlMapDoctypeRegex.test(source)) {
      return source.replace(sqlMapDoctypeRegex, MYBATIS_DOCTYPE);
    }

    if (/^\s*<\?xml\b/i.test(source)) {
      return source.replace(/^\s*<\?xml\b[^>]*\?>/i, function (match) {
        return match + "\n" + MYBATIS_DOCTYPE;
      });
    }

    return MYBATIS_DOCTYPE + "\n" + source;
  }

  function ensureXmlDeclaration(source) {
    const withoutBom = source.replace(/^\uFEFF/, "");

    if (/^\s*<\?xml\b/i.test(withoutBom)) {
      return withoutBom.replace(/^\s*<\?xml\b[^>]*\?>/i, '<?xml version="1.0" encoding="UTF-8"?>');
    }

    return '<?xml version="1.0" encoding="UTF-8"?>\n' + withoutBom.trimStart();
  }

  function convertRootMapper(source, defaultNamespace, warnings) {
    const openingSqlMapRegex = /<sqlMap\b([^>]*)>/i;
    const match = openingSqlMapRegex.exec(source);

    if (!match) {
      if (/<mapper\b/i.test(source)) {
        return source;
      }

      warnings.push("루트 <sqlMap> 또는 <mapper> 태그를 찾지 못했습니다.");
      return source;
    }

    const attrs = parseAttributes(match[1] || "");
    const namespace = attrs.namespace || defaultNamespace || "converted.mapper";
    let converted = source.replace(openingSqlMapRegex, '<mapper namespace="' + namespace + '">');
    converted = converted.replace(/<\/sqlMap>/gi, "</mapper>");
    return converted;
  }

  function replaceCommonAttributes(source, warnings) {
    let converted = source;
    const before = converted;

    converted = converted.replace(/\bparameterCalss\s*=/gi, "parameterType=");
    converted = converted.replace(/\bparameterClass\s*=/gi, "parameterType=");
    converted = converted.replace(/\bresultClass\s*=/gi, "resultType=");
    converted = converted.replace(/\s+remapResults\s*=\s*(["']).*?\1/gi, "");

    if (converted !== before) {
      warnings.push("parameterClass/resultClass/remapResults를 MyBatis 형식으로 바꿨습니다.");
    }

    return converted;
  }

  function replacePlaceholders(source, warnings) {
    let converted = source;
    const before = converted;

    converted = converted.replace(/#\[\]#/g, "#{item}");
    converted = converted.replace(/\$\[\]\$/g, "${item}");
    converted = converted.replace(/#([^#\r\n]+?)#/g, function (_match, inner) {
      return "#{" + inner.trim() + "}";
    });
    converted = converted.replace(/\$([^$\r\n]+?)\$/g, function (_match, inner) {
      return "${" + inner.trim() + "}";
    });

    if (converted !== before) {
      warnings.push("#...# / $...$ 바인딩을 #{...} / ${...} 로 바꿨습니다.");
    }

    return converted;
  }

  function convertIterate(source, warnings) {
    let converted = source;
    let count = 0;

    converted = converted.replace(/<\s*iterate\b([^>]*)>/gi, function (fullMatch, attrText) {
      const attrs = parseAttributes(attrText || "");
      const collection = attrs.property;

      if (!collection) {
        warnings.push("iterate 태그의 property를 읽지 못해 수동 확인이 필요합니다.");
        return fullMatch;
      }

      count += 1;

      const open = attrs.open ? ' open="' + attrs.open + '"' : "";
      const close = attrs.close ? ' close="' + attrs.close + '"' : "";
      const separator = attrs.conjunction ? ' separator="' + attrs.conjunction + '"' : "";

      return '<foreach collection="' + collection + '" item="item"' + open + close + separator + ">";
    });

    converted = converted.replace(/<\/iterate>/gi, "</foreach>");

    if (count > 0) {
      warnings.push("iterate 태그를 foreach로 바꿨습니다.");
    }

    return converted;
  }

  function convertDynamicTags(source, warnings) {
    let converted = source;
    let changed = 0;

    converted = converted.replace(
      /<\s*(dynamic|isNotNull|isNull|isNotEmpty|isEmpty|isEqual|isNotEqual|isGreaterThan|isGreaterEqual|isLessThan|isLessEqual|isParameterPresent|isNotParameterPresent)\b([^>]*)>/gi,
      function (fullMatch, rawTagName, attrText) {
        const tagName = rawTagName.trim();
        const attrs = parseAttributes(attrText || "");
        changed += 1;

        if (tagName === "dynamic") {
          const prefix = attrs.prepend ? ' prefix="' + attrs.prepend + '"' : "";
          const prefixOverrides = attrs.prepend ? ' prefixOverrides="AND |OR "' : "";
          return "<trim" + prefix + prefixOverrides + ">";
        }

        const test = buildIfTest(tagName, attrs);
        if (!test) {
          warnings.push(tagName + " 태그를 완전히 해석하지 못했습니다. 수동 확인이 필요합니다.");
          return fullMatch;
        }

        const prepend = attrs.prepend ? attrs.prepend + " " : "";
        return '<if test="' + test + '">' + prepend;
      }
    );

    converted = converted.replace(/<\/dynamic>/gi, "</trim>");
    converted = converted.replace(
      /<\/(isNotNull|isNull|isNotEmpty|isEmpty|isEqual|isNotEqual|isGreaterThan|isGreaterEqual|isLessThan|isLessEqual|isParameterPresent|isNotParameterPresent)>/gi,
      "</if>"
    );

    if (changed > 0) {
      warnings.push("대표적인 iBATIS 동적 태그를 MyBatis <if>/<trim>으로 바꿨습니다.");
    }

    return converted;
  }

  function findLegacyTags(source) {
    const remains = [];
    const known = {
      isPropertyAvailable: true,
      isNotPropertyAvailable: true,
      dynamic: true,
      iterate: true,
    };

    source.replace(/<\s*\/?\s*([A-Za-z][\w.-]*)\b/g, function (_full, tagName) {
      if (known[tagName] || /^is[A-Z]/.test(tagName)) {
        if (remains.indexOf(tagName) === -1) {
          remains.push(tagName);
        }
      }
      return _full;
    });

    return remains.sort();
  }

  function prettify(source) {
    return source
      .replace(/\r\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim() + "\n";
  }

  function convertIbatisToMybatis(input, options) {
    const source = String(input || "").trim();
    const warnings = [];

    if (!source) {
      return {
        output: "",
        warnings: [],
      };
    }

    let converted = ensureXmlDeclaration(source);
    converted = replaceDoctype(converted);
    converted = convertRootMapper(converted, options && options.namespace, warnings);
    converted = replaceCommonAttributes(converted, warnings);
    converted = replacePlaceholders(converted, warnings);
    converted = convertIterate(converted, warnings);
    converted = convertDynamicTags(converted, warnings);

    const legacyTags = findLegacyTags(converted);
    if (legacyTags.length > 0) {
      warnings.push("자동 변환 후에도 남은 레거시 태그: " + legacyTags.join(", "));
    }

    return {
      output: prettify(converted),
      warnings: warnings,
    };
  }

  return {
    convertIbatisToMybatis: convertIbatisToMybatis,
  };
});
