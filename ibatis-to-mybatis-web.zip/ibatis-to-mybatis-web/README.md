# iBATIS -> MyBatis 웹 변환기

## 사용 방법

1. `open_converter.bat`를 더블클릭하거나 `index.html`을 브라우저로 엽니다.
2. 왼쪽 `AS-IS iBATIS XML` 칸에 원본 XML 전체를 붙여넣습니다.
3. 오른쪽 `TO-BE MyBatis XML` 칸에 변환 결과가 바로 표시됩니다.
4. `결과 복사` 버튼으로 바로 복사할 수 있습니다.

## 자동 변환 내용

- `DOCTYPE sqlMap` -> `DOCTYPE mapper`
- `<sqlMap>` -> `<mapper namespace="...">`
- `parameterClass`, `parameterCalss` -> `parameterType`
- `resultClass` -> `resultType`
- `remapResults` 제거
- `#변수#` -> `#{변수}`
- `$변수$` -> `${변수}`
- `dynamic` -> `trim`
- `iterate` -> `foreach`
- `isNotNull`, `isNull`, `isNotEmpty`, `isEmpty`
- `isEqual`, `isNotEqual`
- `isGreaterThan`, `isGreaterEqual`, `isLessThan`, `isLessEqual`
- `isParameterPresent`, `isNotParameterPresent`

## 주의

복잡한 레거시 iBATIS 문법은 100% 완전 자동 변환이 어려울 수 있습니다.  
아래 확인 메시지 영역에 수동 확인이 필요한 항목이 표시됩니다.
