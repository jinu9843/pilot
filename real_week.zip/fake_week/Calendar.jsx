import React, { useState, useRef, useEffect } from 'react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  addMonths, 
  subMonths, 
  getISOWeek, 
  isSameMonth,
  isSameDay,
  setYear,
  setMonth
} from 'date-fns';
import styles from './Calendar.module.css';

const Calendar = () => {
  const getWeekValue = (day) => {
    // 1. 주의 목요일 찾기 (일요일 시작 기준)
    // 일요일 (0) -> +4일 -> 목요일
    // 월요일 (1) -> +3일 -> 목요일
    // ...
    // 토요일 (6) -> -2일 -> 목요일
    const thursday = new Date(day);
    thursday.setDate(day.getDate() + (4 - day.getDay()));
    
    const year = thursday.getFullYear();
    const week = getISOWeek(thursday);
    const weekString = week.toString().padStart(2, '0');
    
    return `${year}${weekString}`;
  };

  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedWeek, setSelectedWeek] = useState(() => getWeekValue(new Date()));
  const [highlightedDate, setHighlightedDate] = useState(new Date());
  const [isOpen, setIsOpen] = useState(false);
  const [isYearOpen, setIsYearOpen] = useState(false);
  const [isMonthOpen, setIsMonthOpen] = useState(false);
  const calendarRef = useRef(null);

  // 캘린더 외부 클릭 시 닫기
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target)) {
        setIsOpen(false);
        setIsYearOpen(false);
        setIsMonthOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const nextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const prevMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const handleDateClick = (day, weekIndex, weekHasAllDays, isFirstWeek, isLastWeek, weekDays) => {
    const weekValue = getWeekValue(day);
    
    // 일요일이 포함되어 있는지 확인
    const hasSunday = weekDays.some(weekDay => weekDay.getDay() === 0);
    
    let finalWeekValue = weekValue;
    // 일요일이 포함되어 있고, 7일 모두 있지 않으면 A/B 붙이기
    // 7일 모두 있으면 A/B 제거
    if (isFirstWeek && hasSunday && !weekHasAllDays) {
      finalWeekValue = weekValue + 'A';
    } else if (isLastWeek && hasSunday && !weekHasAllDays) {
      finalWeekValue = weekValue + 'B';
    }
    
    setSelectedWeek(finalWeekValue);
    setHighlightedDate(day); // 선택한 날짜 강조 표시
    
    // 선택한 날짜의 월로 캘린더 뷰 전환
    setCurrentDate(day);

    setIsOpen(false); // 선택 후 캘린더 닫기
  };
  
  const handleWeekClick = (weekValue, weekIndex, weekHasAllDays, isFirstWeek, isLastWeek, weekDays) => {
    // 일요일이 포함되어 있는지 확인
    const hasSunday = weekDays.some(weekDay => weekDay.getDay() === 0);
    
    let finalWeekValue = weekValue;
    // 일요일이 포함되어 있고, 7일 모두 있지 않으면 A/B 붙이기
    // 7일 모두 있으면 A/B 제거
    if (isFirstWeek && hasSunday && !weekHasAllDays) {
      finalWeekValue = weekValue + 'A';
    } else if (isLastWeek && hasSunday && !weekHasAllDays) {
      finalWeekValue = weekValue + 'B';
    }
    
    setSelectedWeek(finalWeekValue);
    setHighlightedDate(null); // 파란색 날짜 강조 표시 제거
    setIsOpen(false);
  };

  const toggleCalendar = () => {
    if (!isOpen && highlightedDate) {
      // 캘린더를 열 때, 강조 표시된 날짜의 월로 currentDate 설정
      setCurrentDate(highlightedDate);
    }
    setIsOpen(!isOpen);
  };

  const handleYearClick = (year) => {
    setCurrentDate(setYear(currentDate, year));
    setIsYearOpen(false);
  };

  const handleMonthClick = (month) => {
    setCurrentDate(setMonth(currentDate, month - 1));
    setIsMonthOpen(false);
  };

  // 드롭다운용 연도 생성 (현재 연도부터 시작, 15년 표시)
  // 사용자가 위/아래로 스크롤할 수 있도록 넓은 범위의 연도 생성
  // 현재 연도를 상단에 스크롤
  const years = Array.from({ length: 200 }, (_, i) => 1900 + i);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);

  // 스크롤 처리를 위한 드롭다운 refs
  const yearDropdownRef = useRef(null);
  const monthDropdownRef = useRef(null);

  useEffect(() => {
    if (isYearOpen && yearDropdownRef.current) {
      const selectedYearEl = yearDropdownRef.current.querySelector(`.${styles['selected-item']}`);
      if (selectedYearEl) {
        selectedYearEl.scrollIntoView({ block: 'start' });
      }
    }
  }, [isYearOpen]);

  useEffect(() => {
    if (isMonthOpen && monthDropdownRef.current) {
      const selectedMonthEl = monthDropdownRef.current.querySelector(`.${styles['selected-item']}`);
      if (selectedMonthEl) {
        selectedMonthEl.scrollIntoView({ block: 'start' });
      }
    }
  }, [isMonthOpen]);


  // 캘린더 그리드 생성
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 0 }); 
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 0 }); 

  const calendarDays = eachDayOfInterval({
    start: startDate,
    end: endDate,
  });

  const weeks = [];
  let week = [];
  calendarDays.forEach((day) => {
    week.push(day);
    if (week.length === 7) {
      weeks.push(week);
      week = [];
    }
  });

  const weekHeaders = ['주차', '일', '월', '화', '수', '목', '금', '토'];

  return (
    <div className={styles['calendar-wrapper']} ref={calendarRef}>
      <div className={styles['input-container']} onClick={toggleCalendar}>
        <input 
          type="text" 
          value={selectedWeek} 
          readOnly 
          placeholder="주차 선택"
          className={styles['calendar-input']} 
        />
      </div>

      {isOpen && (
        <div className={styles['calendar-popup']}>
            <div className={styles['calendar-container']}>
            <div className={styles['header-controls']}>
              <button onClick={prevMonth}>&lt;</button>
              <div className={styles['header-title']}>
                <div className={styles['dropdown-container']}>
                  <span onClick={() => { setIsYearOpen(!isYearOpen); setIsMonthOpen(false); }} className={styles['header-clickable']}>
                    {format(currentDate, 'yyyy년')}
                  </span>
                  {isYearOpen && (
                    <div className={`${styles['dropdown-menu']} ${styles['year-dropdown']}`} ref={yearDropdownRef}>
                      {years.map(year => (
                        <div 
                          key={year} 
                          className={`${styles['dropdown-item']} ${year === currentDate.getFullYear() ? styles['selected-item'] : ''}`}
                          onClick={() => handleYearClick(year)}
                        >
                          {year}년
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className={styles['dropdown-container']}>
                  <span onClick={() => { setIsMonthOpen(!isMonthOpen); setIsYearOpen(false); }} className={styles['header-clickable']}>
                    {format(currentDate, 'M월')}
                  </span>
                  {isMonthOpen && (
                    <div className={`${styles['dropdown-menu']} ${styles['month-dropdown']}`} ref={monthDropdownRef}>
                      {months.map(month => (
                        <div 
                          key={month} 
                          className={`${styles['dropdown-item']} ${month === currentDate.getMonth() + 1 ? styles['selected-item'] : ''}`}
                          onClick={() => handleMonthClick(month)}
                        >
                          {month}월
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <button onClick={nextMonth}>&gt;</button>
            </div>

            <div className={styles['calendar-grid']}>
              {weekHeaders.map((header) => (
                <div key={header} className={`${styles['calendar-cell']} ${styles['header-cell']} ${header === '일' ? styles['sunday-header'] : ''}`}>
                  {header}
                </div>
              ))}

              {weeks.map((weekDays, weekIndex) => {
                const thursdayOfWeek = weekDays[4];
                const weekNumber = getISOWeek(thursdayOfWeek);
                const weekYear = thursdayOfWeek.getFullYear();
                const weekValue = `${weekYear}${weekNumber.toString().padStart(2, '0')}`;
                
                const isSelectedWeek = weekValue === selectedWeek;
                
                // 첫째 주와 마지막 주 확인
                const isFirstWeek = weekIndex === 0;
                const isLastWeek = weekIndex === weeks.length - 1;
                
                // 해당 주가 7일 모두 현재 달에 속하는지 확인
                const weekHasAllDays = weekDays.every(day => isSameMonth(day, monthStart));
                
                // 일요일이 포함되어 있는지 확인
                const hasSunday = weekDays.some(day => day.getDay() === 0);
                
                // 주차 표시에 A 또는 B 추가
                // 조건: 일요일이 포함되어 있고, 7일 모두 있지 않으면 A/B 붙이기
                // 7일 모두 있으면 A/B 제거
                let weekDisplay = weekNumber.toString();
                if (isFirstWeek && hasSunday && !weekHasAllDays) {
                  weekDisplay += 'A';
                } else if (isLastWeek && hasSunday && !weekHasAllDays) {
                  weekDisplay += 'B';
                }

                return (
                  <React.Fragment key={weekIndex}>
                    <div 
                      className={`${styles['calendar-cell']} ${styles['week-number-cell']} ${
                        isSelectedWeek || 
                        (isFirstWeek && hasSunday && !weekHasAllDays && selectedWeek === weekValue + 'A') ||
                        (isLastWeek && hasSunday && !weekHasAllDays && selectedWeek === weekValue + 'B')
                          ? styles['selected-week-number'] : ''
                      }`}
                      onClick={() => handleWeekClick(weekValue, weekIndex, weekHasAllDays, isFirstWeek, isLastWeek, weekDays)}
                    >
                      {weekDisplay}
                    </div>
                    {weekDays.map((day) => {
                      const isNotCurrentMonth = !isSameMonth(day, monthStart);
                      const isHighlighted = highlightedDate && 
                        isSameDay(day, highlightedDate) && 
                        isSameMonth(day, monthStart);
                      const isSunday = day.getDay() === 0;
                      return (
                        <div 
                          key={day.toISOString()} 
                          className={`${styles['calendar-cell']} ${styles['day-cell']} ${
                            isNotCurrentMonth ? styles['not-current-month'] : ''
                          } ${isSameDay(day, new Date()) ? styles['today'] : ''} ${
                            isHighlighted ? styles['selected'] : ''
                          } ${isSunday && !isNotCurrentMonth ? styles['sunday'] : ''}`}
                          onClick={() => {
                            if (!isNotCurrentMonth) {
                              handleDateClick(day, weekIndex, weekHasAllDays, isFirstWeek, isLastWeek, weekDays);
                            }
                          }}
                        >
                          {isNotCurrentMonth && !isHighlighted ? '' : format(day, 'd')}
                        </div>
                      );
                    })}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Calendar;
