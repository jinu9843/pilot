import Calendar from './Calendar';
import './App.css';

function App() {
  return (
    <div className="App" style={{ padding: '50px', display: 'flex', justifyContent: 'center' }}>
      <Calendar />
    </div>
  );
}

export default App;
