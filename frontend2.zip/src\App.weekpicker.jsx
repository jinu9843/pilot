import { useMemo, useState } from 'react'
import dayjs from 'dayjs'
import isoWeek from 'dayjs/plugin/isoWeek'
import './App.css'

dayjs.extend(isoWeek)

const formatWeekKey = ({ year, week }) =>
  `${year}${week.toString().padStart(2, '0')}`

const getWeekKey = (date) => ({
  year: date.isoWeekYear(),
  week: date.isoWeek(),
})

const buildMonthWeeks = (anchor) => {
  const monthStart = anchor.startOf('month')
  const monthEnd = anchor.endOf('month')
  const start = monthStart.startOf('isoWeek')
  const weeks = []
  let cursor = start

  while (cursor.isBefore(monthEnd.endOf('isoWeek'))) {
    const days = Array.from({ length: 7 }, (_, i) => cursor.add(i, 'day'))
    weeks.push({ key: getWeekKey(cursor), days })
    cursor = cursor.add(1, 'week')
  }
  return weeks
}

const getDateFromWeekKey = (key) =>
  dayjs(`${key.year}-01-04`).isoWeek(key.week).startOf('isoWeek')

function WeekPicker() {
  const today = useMemo(() => dayjs(), [])
  const [isOpen, setIsOpen] = useState(false)
  const [anchorMonth, setAnchorMonth] = useState(today.startOf('month'))
  const [activeDate, setActiveDate] = useState(today)

  const toggleCalendar = () => {
    setIsOpen((prev) => {
      const next = !prev
      if (next) {
        setAnchorMonth(activeDate.startOf('month'))
      }
      return next
    })
  }

  const handleDayClick = (day) => {
    setActiveDate(day)
    setIsOpen(false)
  }

  const handleWeekClick = (weekKey) => {
    const newDate = getDateFromWeekKey(weekKey)
    setActiveDate(newDate)
    setAnchorMonth(newDate.startOf('month'))
    setIsOpen(false)
  }

  const selectedWeek = getWeekKey(activeDate)
  const weeks = buildMonthWeeks(anchorMonth)
  const currentYear = anchorMonth.year()
  const yearOptions = Array.from({ length: 31 }, (_, i) => currentYear - 15 + i)
  const monthOptions = Array.from({ length: 12 }, (_, i) => i + 1)

  return (
    <div className="week-picker">
      <label>주차</label>
      <div className="input-wrapper">
        <input value={formatWeekKey(selectedWeek)} readOnly onClick={toggleCalendar} />
        <button type="button" onClick={toggleCalendar}>
          📅
        </button>
      </div>

      {isOpen && (
        <div className="popover">
          <header>
            <button onClick={() => setAnchorMonth(anchorMonth.subtract(1, 'month'))}>
              {'<'}
            </button>
            <div className="selectors">
              <select
                value={anchorMonth.year()}
                onChange={(e) => {
                  const year = Number(e.target.value)
                  setAnchorMonth(anchorMonth.year(year))
                }}
              >
                {yearOptions.map((year) => (
                  <option key={year} value={year}>
                    {year}년
                  </option>
                ))}
              </select>
              <select
                value={anchorMonth.month() + 1}
                onChange={(e) => {
                  const month = Number(e.target.value) - 1
                  setAnchorMonth(anchorMonth.month(month))
                }}
              >
                {monthOptions.map((month) => (
                  <option key={month} value={month}>
                    {month}월
                  </option>
                ))}
              </select>
            </div>
            <button onClick={() => setAnchorMonth(anchorMonth.add(1, 'month'))}>
              {'>'}
            </button>
          </header>
          <table>
            <thead>
              <tr>
                <th>주차</th>
                <th>월</th>
                <th>화</th>
                <th>수</th>
                <th>목</th>
                <th>금</th>
                <th>토</th>
                <th>일</th>
              </tr>
            </thead>
            <tbody>
              {weeks.map(({ key, days }) => (
                <tr key={formatWeekKey(key)}>
                  <td className="week-col">
                    <button
                      type="button"
                      className={
                        key.year === selectedWeek.year && key.week === selectedWeek.week
                          ? 'week-active'
                          : undefined
                      }
                      onClick={() => handleWeekClick(key)}
                    >
                      {key.week}
                    </button>
                  </td>
                  {days.map((day) => (
                    <td key={day.toString()}>
                      <button
                        type="button"
                        className={[
                          day.isSame(activeDate, 'day') ? 'active' : '',
                          day.isSame(today, 'day') ? 'today' : '',
                        ]
                          .join(' ')
                          .trim() || undefined}
                        onClick={() => handleDayClick(day)}
                      >
                        {day.date()}
                      </button>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

function App() {
  return (
    <div style={{ padding: 24 }}>
      <WeekPicker />
    </div>
  )
}

export default App
