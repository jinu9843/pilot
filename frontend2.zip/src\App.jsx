import { useMemo, useState } from 'react'
import dayjs from 'dayjs'
import isoWeek from 'dayjs/plugin/isoWeek'
import { DayPicker } from 'react-day-picker'
import 'react-day-picker/style.css'
import './App.css'

dayjs.extend(isoWeek)

const formatWeekKey = ({ year, week }) =>
  `${year}${week.toString().padStart(2, '0')}`

const getWeekKey = (date) => ({
  year: date.isoWeekYear(),
  week: date.isoWeek(),
})

function WeekPicker() {
  const today = useMemo(() => dayjs(), [])
  const [isOpen, setIsOpen] = useState(false)
  const [selectedDate, setSelectedDate] = useState(today)
  const [month, setMonth] = useState(today.startOf('month').toDate())

  const toggleCalendar = () => {
    setIsOpen((prev) => {
      const next = !prev
      if (next) {
        setMonth(selectedDate.startOf('month').toDate())
      }
      return next
    })
  }

  const closeWithDate = (date) => {
    setSelectedDate(date)
    setMonth(date.startOf('month').toDate())
    setIsOpen(false)
  }

  const handleDaySelect = (day) => {
    if (!day) return
    closeWithDate(dayjs(day))
  }

  const handleWeekClick = (weekStart) => {
    closeWithDate(weekStart)
  }

  const selectedWeek = getWeekKey(selectedDate)
  const selectedWeekId = formatWeekKey(selectedWeek)
  const fromYear = today.year() - 15
  const toYear = today.year() + 15

  const WeekNumberCell = (props) => {
    const { week, ...thProps } = props
    const referenceDay = week.days[3] ?? week.days[0]
    const refDate = dayjs(referenceDay.date)
    const weekStart = refDate.startOf('isoWeek')
    const weekKey = getWeekKey(refDate)
    const weekId = formatWeekKey(weekKey)
    const isActive = weekId === selectedWeekId

    return (
      <th {...thProps}>
        <button
          type="button"
          className={isActive ? 'week-number-btn week-active' : 'week-number-btn'}
          onClick={() => handleWeekClick(weekStart)}
        >
          {weekKey.week}
        </button>
      </th>
    )
  }

  const WeekNumberHeaderCell = (props) => (
    <th {...props} className="week-header">
      주차
    </th>
  )

  return (
    <div className="week-picker">
      <label>주차</label>
      <div className="input-wrapper">
        <input value={formatWeekKey(selectedWeek)} readOnly onClick={toggleCalendar} />
        <button type="button" onClick={toggleCalendar}>
          📅
        </button>
      </div>

      {isOpen && (
        <div className="popover calendar-popover">
          <DayPicker
            mode="single"
            selected={selectedDate.toDate()}
            onSelect={handleDaySelect}
            showWeekNumber
            ISOWeek
            weekStartsOn={1}
            month={month}
            onMonthChange={setMonth}
            captionLayout="dropdown"
            fromYear={fromYear}
            toYear={toYear}
            modifiers={{
              today: today.toDate(),
            }}
            modifiersClassNames={{
              today: 'today-cell',
            }}
            components={{
              WeekNumber: WeekNumberCell,
              WeekNumberHeader: WeekNumberHeaderCell,
            }}
          />
        </div>
      )}
    </div>
  )
}

function App() {
  return (
    <div style={{ padding: 24 }}>
      <WeekPicker />
    </div>
  )
}

export default App
