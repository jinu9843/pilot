// signlw 로컬 목 — test 프로젝트용 (Transfer / Modal / Table / Button)
import React, { useMemo, useState } from 'react'

export const Button = ({ children, onClick, type, style, disabled }) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    style={{
      height: 28,
      padding: '0 14px',
      fontSize: 12,
      borderRadius: 2,
      cursor: disabled ? 'not-allowed' : 'pointer',
      border: `1px solid ${type === 'primary' ? '#294579' : '#c4ccd7'}`,
      background:
        type === 'primary'
          ? 'linear-gradient(#4c77bf, #395f9b)'
          : 'linear-gradient(#f8f9fc, #e5e8f1)',
      color: type === 'primary' ? '#fff' : '#333',
      opacity: disabled ? 0.55 : 1,
      ...style,
    }}
  >
    {children}
  </button>
)

const overlayStyle = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0,0,0,0.45)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1000,
}

export const Modal = ({
  title,
  open,
  onOk,
  onCancel,
  okText = '확인',
  cancelText = '취소',
  okButtonProps,
  width = 520,
  children,
}) => {
  if (!open) return null
  return (
    <div style={overlayStyle} onClick={onCancel} role="presentation">
      <div
        style={{
          background: '#fff',
          borderRadius: 4,
          width,
          maxWidth: '96vw',
          maxHeight: '85vh',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 6px 24px rgba(0,0,0,0.22)',
        }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '10px 16px',
            background: 'linear-gradient(#4c77bf, #395f9b)',
            color: '#fff',
            fontSize: 13,
            fontWeight: 600,
            borderRadius: '4px 4px 0 0',
          }}
        >
          <span>{title}</span>
          <button
            type="button"
            onClick={onCancel}
            style={{
              background: 'none',
              border: 'none',
              color: '#fff',
              cursor: 'pointer',
              fontSize: 14,
            }}
          >
            ✕
          </button>
        </div>
        <div style={{ flex: 1, padding: 16, overflowY: 'auto' }}>{children}</div>
        <div
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
            gap: 8,
            padding: '10px 16px',
            borderTop: '1px solid #e0e0e0',
            background: '#f7f9fc',
            borderRadius: '0 0 4px 4px',
          }}
        >
          <Button onClick={onCancel}>{cancelText}</Button>
          <Button type="primary" onClick={onOk} disabled={okButtonProps?.disabled}>
            {okText}
          </Button>
        </div>
      </div>
    </div>
  )
}

export const Table = ({ dataSource = [], columns = [], style }) => (
  <table
    style={{
      borderCollapse: 'collapse',
      fontSize: 12,
      width: '100%',
      ...style,
    }}
  >
    <thead>
      <tr>
        {columns.map((col) => (
          <th
            key={col.key || col.dataIndex}
            style={{
              padding: '6px 8px',
              background: '#f0f4ff',
              border: '1px solid #d0d8e8',
              textAlign: 'left',
              whiteSpace: 'nowrap',
            }}
          >
            {col.title}
          </th>
        ))}
      </tr>
    </thead>
    <tbody>
      {dataSource.map((row, i) => (
        <tr key={row.key ?? i}>
          {columns.map((col) => (
            <td
              key={col.key || col.dataIndex}
              style={{ padding: '6px 8px', border: '1px solid #e8ecf2' }}
            >
              {col.render ? col.render(row[col.dataIndex], row) : row[col.dataIndex]}
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  </table>
)

/**
 * Ant Design Transfer 와 유사한 API
 * - dataSource: { key, title, disabled? }[]
 * - targetKeys: 오른쪽(미조회/기본 풀)에 표시할 key 목록
 * - onChange(nextTargetKeys, direction, moveKeys)
 */
export const Transfer = ({
  dataSource = [],
  targetKeys = [],
  onChange,
  titles = ['', ''],
  listStyle,
  operations = ['>', '<'],
}) => {
  const [leftSelected, setLeftSelected] = useState([])
  const [rightSelected, setRightSelected] = useState([])

  const targetSet = useMemo(() => new Set(targetKeys), [targetKeys])
  const leftItems = useMemo(
    () => dataSource.filter((d) => !targetSet.has(d.key)),
    [dataSource, targetSet],
  )
  const rightItems = useMemo(
    () => dataSource.filter((d) => targetSet.has(d.key)),
    [dataSource, targetSet],
  )

  const toggle = (key, side) => {
    if (side === 'left') {
      setLeftSelected((prev) =>
        prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
      )
    } else {
      setRightSelected((prev) =>
        prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
      )
    }
  }

  const moveToRight = () => {
    const moveKeys = leftSelected.filter((k) => {
      const item = dataSource.find((d) => d.key === k)
      return item && !item.disabled
    })
    if (moveKeys.length === 0) return
    const next = [...new Set([...targetKeys, ...moveKeys])]
    onChange?.(next, 'right', moveKeys)
    setLeftSelected([])
  }

  const moveToLeft = () => {
    const moveKeys = rightSelected.filter((k) => {
      const item = dataSource.find((d) => d.key === k)
      return item && !item.disabled
    })
    if (moveKeys.length === 0) return
    const next = targetKeys.filter((k) => !moveKeys.includes(k))
    onChange?.(next, 'left', moveKeys)
    setRightSelected([])
  }

  const listBoxStyle = {
    flex: 1,
    minWidth: 0,
    display: 'flex',
    flexDirection: 'column',
    border: '1px solid #d0d8e8',
    borderRadius: 2,
    background: '#fff',
    ...listStyle,
  }

  const renderList = (items, side, selected) => (
    <div style={listBoxStyle}>
      <div
        style={{
          padding: '6px 10px',
          borderBottom: '1px solid #e8ecf2',
          fontSize: 12,
          fontWeight: 600,
          color: '#333',
          background: '#f7f9fc',
        }}
      >
        {side === 'left' ? titles[0] : titles[1]}
      </div>
      <div style={{ flex: 1, overflowY: 'auto', maxHeight: 320 }}>
        {items.length === 0 ? (
          <div style={{ padding: 12, color: '#999', fontSize: 12 }}>항목 없음</div>
        ) : (
          items.map((item) => {
            const checked = selected.includes(item.key)
            return (
              <label
                key={item.key}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '6px 10px',
                  fontSize: 12,
                  cursor: item.disabled ? 'not-allowed' : 'pointer',
                  opacity: item.disabled ? 0.45 : 1,
                  background: checked ? '#e8f0ff' : 'transparent',
                }}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  disabled={item.disabled}
                  onChange={() => !item.disabled && toggle(item.key, side)}
                />
                <span>{item.title}</span>
              </label>
            )
          })
        )}
      </div>
    </div>
  )

  return (
    <div style={{ display: 'flex', alignItems: 'stretch', gap: 12 }}>
      {renderList(leftItems, 'left', leftSelected)}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          gap: 8,
          flexShrink: 0,
        }}
      >
        <Button onClick={moveToRight} disabled={leftSelected.length === 0}>
          {operations[0] ?? '>'}
        </Button>
        <Button onClick={moveToLeft} disabled={rightSelected.length === 0}>
          {operations[1] ?? '<'}
        </Button>
      </div>
      {renderList(rightItems, 'right', rightSelected)}
    </div>
  )
}
