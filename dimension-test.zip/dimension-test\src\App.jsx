/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  이 파일 하나만 복사해서 이슈에 붙여넣어도, “무슨 데이터인지”를 읽을 수 있게   ║
 * ║  목(가짜) 데이터 + 가짜 API 함수를 전부 이 안에 넣었어요.                  ║
 * ║                                                                          ║
 * ║  ⚠️ 회사 실제 프로젝트에서는 아래 두 줄이 필요해요 (지금 test 폴더 설정):    ║
 * ║     import { Button, Modal, Table, Transfer } from 'signlw'             ║
 * ║     → vite.config.js 에서 signlw 를 목(mock) 파일로 연결해 두었습니다.    ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

// React 에서 “처음 한 번만 실행”, “기억해야 하는 값”만 가져와요.
// useMemo / useCallback 은 쓰지 않아요. (읽기 어려우니까 그냥 매번 계산해요. 이 화면은 가벼워요.)
import { useEffect, useState } from 'react'
// 회사 UI 라이브러리(signlw)에서 버튼·모달·표·이동창(Transfer)을 가져와요.
import { Button, Modal, Table, Transfer } from 'signlw'
// 화면 예쁘게 보이게 하는 CSS 파일이에요. (이 파일 내용은 복사 대상이 아니어도 됨)
import './App.css'

// ─────────────────────────────────────────────────────────────────────────────
// [유치원 선생님 말] “sleep” 은 “잠깐 기다려!” 하는 가짜 타이머예요.
// 진짜 인터넷(API)은 시간이 걸리니까, 목 데이터도 그 느낌을 흉내 냅니다.
// ─────────────────────────────────────────────────────────────────────────────
/** @param {number} ms 밀리초 (1000 = 1초) */
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// ─────────────────────────────────────────────────────────────────────────────
// [유치원 선생님 말] 아래 배열은 “서버가 보내준 컬럼 목록”을 가짜로 적어 둔 거예요.
// 각 줄(객체)은 “그리드에 쓸 수 있는 칸(컬럼) 하나”를 뜻해요.
//
// COL_NM      : 컬럼의 영문 이름(프로그램에서 쓰는 키). 엑셀 칸 이름 같아요.
// KOR_COL_NM  : 사람이 보기 좋은 한글 이름.
// DEFAULT_YN  : 'Y' 이면 “처음부터 오른쪽(그리드에 보이는 쪽)”에 두겠다는 뜻.
//               'N' 이면 “처음엔 왼쪽(안 보이는 쪽)”에 두겠다는 뜻.
// ─────────────────────────────────────────────────────────────────────────────
const MOCK_META = [
  // 지역은 처음엔 안 보이게(왼쪽) 시작
  { COL_NM: 'REGION', KOR_COL_NM: '지역', DEFAULT_YN: 'N' },
  // 기간도 처음엔 안 보이게(왼쪽) 시작
  { COL_NM: 'PERIOD', KOR_COL_NM: '기간', DEFAULT_YN: 'N' },
  // 제품도 처음엔 안 보이게(왼쪽) 시작
  { COL_NM: 'PRODUCT', KOR_COL_NM: '제품', DEFAULT_YN: 'N' },
  // 금액은 처음부터 보이게(오른쪽) 시작
  { COL_NM: 'AMOUNT', KOR_COL_NM: '금액', DEFAULT_YN: 'Y' },
  // 수량도 처음부터 보이게(오른쪽) 시작
  { COL_NM: 'QTY', KOR_COL_NM: '수량', DEFAULT_YN: 'Y' },
  // 비고도 처음부터 보이게(오른쪽) 시작
  { COL_NM: 'MEMO', KOR_COL_NM: '비고', DEFAULT_YN: 'Y' },
]

// ─────────────────────────────────────────────────────────────────────────────
// [유치원 선생님 말] 아래는 “서버가 보내준 데이터 줄(행)”을 가짜로 적어 둔 거예요.
// 한 객체 = 표에서 가로 한 줄.
// ─────────────────────────────────────────────────────────────────────────────
const MOCK_ROWS = [
  { REGION: '서울', PERIOD: '2026-01', PRODUCT: 'A', AMOUNT: 1200, QTY: 10, MEMO: '샘플1' },
  { REGION: '부산', PERIOD: '2026-02', PRODUCT: 'B', AMOUNT: 800, QTY: 5, MEMO: '샘플2' },
  { REGION: '대전', PERIOD: '2026-03', PRODUCT: 'C', AMOUNT: 2100, QTY: 12, MEMO: '샘플3' },
]

/**
 * [유치원 선생님 말] “컬럼 설명서 목록을 서버에서 받아왔다!” 를 흉내 내는 함수예요.
 * 나중에 회사에서는 여기만 axios.post(...) 같은 진짜 호출로 바꾸면 됩니다.
 */
async function fetchColumnMeta() {
  await sleep(180) // 0.18초 기다리기 (로딩 느낌)
  return [...MOCK_META] // 배열을 복사해서 돌려줌 (원본을 바로 주면 위험할 수 있어서)
}

/**
 * [유치원 선생님 말] “지금 그리드에 보여줄 칸 이름들(colKeys)”만 골라서
 * 각 행에서 그 칸들만 잘라서 돌려주는 가짜 조회 함수예요.
 * @param {string[]} colKeys 오른쪽(노출)에 있는 컬럼 이름들의 순서 배열
 */
async function fetchGridRows(colKeys) {
  await sleep(120) // 0.12초 기다리기
  const keys = Array.isArray(colKeys) ? colKeys : [] // colKeys가 배열이 아니면 빈 배열로 처리
  // MOCK_ROWS 의 각 줄을 돌면서…
  return MOCK_ROWS.map((row, idx) => {
    const sliced = { key: `row-${idx}` } // React 표가 줄을 구분하려고 key 가 필요해요
    // colKeys 에 적힌 순서대로, 원래 row 에 있던 값만 복사해 넣기
    keys.forEach((k) => {
      // row 안에 그 이름(k)의 칸이 있을 때만 복사 (없는 이름이 들어와도 안전)
      if (Object.prototype.hasOwnProperty.call(row, k)) {
        sliced[k] = row[k]
      }
    })
    return sliced // 잘린 한 줄을 결과 배열에 넣기
  })
}

/**
 * [유치원 선생님 말] “설명서(MOCK_META)에 적힌 순서”를 지키면서,
 * 오른쪽(노출) 목록(targetKeys)에 들어있는 컬럼만 골라서 이름 배열로 돌려줘요.
 * (그리드 컬럼 순서를 예쁘게 맞추려고 이렇게 해요.)
 */
function exposedKeysOrdered(metaList, targetKeys) {
  const exposed = new Set(targetKeys) // 빠르게 “포함되어 있나?”를 찾기 위한 주머니(Set)
  // metaList 를 앞에서부터 훑으면서…
  return (
    metaList
      // 오른쪽 주머니에 들어있는 COL_NM 만 남기고
      .filter((m) => exposed.has(m.COL_NM))
      // 이름(COL_NM)만 뽑아서 배열로 만들기
      .map((m) => m.COL_NM)
  )
}

/**
 * [유치원 선생님 말] Transfer 가 이해하는 모양으로 바꿔요.
 * Transfer 는 { key, title } 리스트를 좋아해요.
 */
function buildDataSource(metaList) {
  return metaList.map((m) => ({
    key: m.COL_NM, // 이 컬럼의 고유 이름(키)
    title: `${m.KOR_COL_NM} (${m.COL_NM})`, // 화면에 보여줄 글자(한글 + 영문)
  }))
}

/**
 * [유치원 선생님 말] 처음에 오른쪽으로 보낼 컬럼들을 고르는 규칙이에요:
 * “DEFAULT_YN 이 'Y' 인 것만 오른쪽으로!”
 */
function initialRightKeysFromApi(metaList) {
  return metaList.filter((m) => m.DEFAULT_YN === 'Y').map((m) => m.COL_NM)
}

// ═════════════════════════════════════════════════════════════════════════════
// [유치원 선생님 말] 아래부터는 “진짜 화면(App)” 이에요. export default 는
// “이 파일의 주인공 컴포넌트는 App 이야!” 라고 알려주는 표시예요.
// ═════════════════════════════════════════════════════════════════════════════
export default function App() {
  // loading: true 이면 “지금 불러오는 중…” 이라고 보여줄 거예요.
  const [loading, setLoading] = useState(true)

  // meta: 서버(가짜)에서 받은 컬럼 설명서 목록을 여기 저장해요.
  const [meta, setMeta] = useState([])

  // rightTargetKeys: Transfer 의 “오른쪽”에 있는 컬럼 이름들이에요.
  // 우리 규칙: 오른쪽 = 그리드에 노출(보이는 칸).
  const [rightTargetKeys, setRightTargetKeys] = useState([])

  // gridRows: 표(Table)에 넣을 “데이터 줄들”이에요.
  const [gridRows, setGridRows] = useState([])

  // dimOpen: 디멘션 팝업(Modal)이 열렸는지 닫혔는지예요. true = 열림.
  const [dimOpen, setDimOpen] = useState(false)

  // draftRightKeys: 팝업 안에서만 연습하는 “오른쪽 목록”이에요.
  // [왜 필요해?] 적용 전에는 저장하면 안 되니까, 임시 메모장이라고 생각하면 돼요.
  const [draftRightKeys, setDraftRightKeys] = useState([])

  // meta 가 바뀔 때마다(화면이 그려질 때마다) Transfer 가 먹을 dataSource 를 새로 만들어요.
  // (useMemo 없이 그냥 계산 — 이 정도 데이터는 매번 만들어도 전혀 문제 없어요.)
  const dataSource = buildDataSource(meta)

  // “지금 오른쪽 목록(rightKeys)대로 그리드를 다시 불러오기” — 그냥 함수 하나예요. (useCallback 없음)
  async function loadGrid(rightKeys) {
    const cols = exposedKeysOrdered(meta, rightKeys) // 오른쪽 컬럼들을 순서대로 정리
    const rows = await fetchGridRows(cols) // 그 컬럼들만 잘라서 데이터 받기(가짜)
    setGridRows(rows) // 받은 줄들을 state 에 저장 → 화면이 바뀜
  }

  // [유치원 선생님 말] 컴포넌트가 처음 화면에 붙을 때 딱 한 번 실행되는 구역이에요.
  useEffect(() => {
    let cancelled = false // “이미 그만뒀는데 늦게 도착한 응답은 버려!” 표시

    ;(async () => {
      setLoading(true) // 로딩 시작
      try {
        const list = await fetchColumnMeta() // 가짜 컬럼 설명서 받기
        if (cancelled) return // 그만뒌으면 여기서 끝

        setMeta(list) // 설명서 저장

        const initialRight = initialRightKeysFromApi(list) // 처음 오른쪽에 둘 이름들
        setRightTargetKeys(initialRight) // “진짜 적용된 오른쪽 목록”에도 반영

        const cols = exposedKeysOrdered(list, initialRight) // 처음 표에 보일 칸 순서
        const rows = await fetchGridRows(cols) // 처음 표 데이터
        if (!cancelled) setGridRows(rows) // 그만두지 않았으면 표 데이터 저장
      } finally {
        // 성공/실패 상관없이 로딩은 끝내요.
        if (!cancelled) setLoading(false)
      }
    })()

    // [유치원 선생님 말] “페이지를 떠나거나 다시 그릴 때” 늦게 도착한 응답이 state 를 망가뜨리지 않게 해요.
    return () => {
      cancelled = true
    }
  }, []) // [] 는 “처음 한 번만!” 이라는 뜻이에요.

  // 표 머리(컬럼 정의)를 meta + rightTargetKeys 로부터 매번 계산해요. (useMemo 없음)
  const colsForGrid = exposedKeysOrdered(meta, rightTargetKeys) // 지금 노출 중인 칸 이름들
  const gridColumns = colsForGrid.map((col) => {
    const m = meta.find((x) => x.COL_NM === col) // 설명서에서 한글 이름 찾기
    return {
      key: col, // React/표가 구분할 키
      dataIndex: col, // 각 줄 객체에서 어떤 칸을 읽을지
      title: m ? `${m.KOR_COL_NM}` : col, // 머리글에 보여줄 글자
    }
  })

  // “디멘션” 버튼을 눌렀을 때: 지금 상태를 임시 메모장에 복사하고 팝업을 열어요.
  const openDimension = () => {
    setDraftRightKeys([...rightTargetKeys]) // 배열을 통째로 복사(같은 배열을 주면 위험)
    setDimOpen(true) // 팝업 열기
  }

  // Transfer 안에서 오른쪽 목록이 바뀔 때마다 호출돼요. → 임시 메모장만 갱신
  const handleTransferChange = (nextTargetKeys) => {
    setDraftRightKeys(nextTargetKeys)
  }

  // “적용” 버튼: 임시 메모장을 진짜로 확정하고, 표 데이터를 다시 받아요.
  const handleApplyDimension = async () => {
    setRightTargetKeys([...draftRightKeys]) // 진짜 오른쪽 목록 확정
    setDimOpen(false) // 팝업 닫기
    setLoading(true) // 다시 불러오는 중 표시
    try {
      await loadGrid(draftRightKeys) // 확정된 오른쪽 기준으로 표 데이터 갱신
    } finally {
      setLoading(false) // 로딩 끝
    }
  }

  // “취소”: 팝업만 닫아요. (임시 메모장은 저장하지 않음 → 다음에 열면 다시 복사됨)
  const handleCancelDimension = () => {
    setDimOpen(false)
  }

  // ─────────────────────────────────────────────────────────────────────────
  // [유치원 선생님 말] return ( ... ) 안은 “화면에 그릴 그림(HTML 비슷한 것)”이에요.
  // JSX 라고 불러요: JavaScript 안에 HTML 모양을 섞어 쓰는 문법이에요.
  // ─────────────────────────────────────────────────────────────────────────
  return (
    // 페이지 전체를 감싸는 큰 상자 (CSS 클래스 이름은 App.css 에 정의)
    <div className="dim-page">
      {/* header: 위쪽 줄(제목 + 버튼) */}
      <header className="dim-header">
        {/* h1: 페이지 제목 */}
        <h1 className="dim-title">디멘션 컬럼 선택</h1>
        {/* Button: signlw 버튼. type="primary" 는 파란 강조 버튼 스타일 */}
        <Button
          type="primary"
          onClick={openDimension} // 클릭하면 openDimension 함수 실행
          disabled={loading || meta.length === 0} // 로딩 중이거나 설명서가 없으면 못 누름
        >
          디멘션
        </Button>
      </header>

      {/* p: 설명 글 (사용자 안내) */}
      <p className="dim-desc">
        첫 진입 시 API의 <code>DEFAULT_YN</code>이 <code>Y</code>인 컬럼은 오른쪽(그리드 노출),
        그렇지 않으면 왼쪽(미노출)에 배치됩니다. 가운데 버튼으로 이동한 뒤 <strong>적용</strong>을
        누르면 <strong>오른쪽(노출) 컬럼만</strong> 그리드에 표시됩니다.
      </p>

      {/* section: 그리드 영역 묶음 */}
      <section className="dim-grid-section">
        <h2 className="dim-section-title">조회 그리드</h2>
        {/* loading 이 true 면 “불러오는 중”, 아니면 표를 보여줘요 */}
        {loading ? (
          <div className="dim-loading">불러오는 중…</div>
        ) : (
          <div className="dim-table-wrap">
            {/* Table: dataSource=줄들, columns=머리글 정의 */}
            <Table dataSource={gridRows} columns={gridColumns} />
          </div>
        )}
      </section>

      {/* Modal: 팝업창. open 이 true 일 때만 보여요( signlw 목 구현 기준 ) */}
      <Modal
        title="디멘션 — 노출 컬럼 설정"
        open={dimOpen}
        onCancel={handleCancelDimension} // X 또는 취소 누르면
        onOk={handleApplyDimension} // 확인/적용 누르면
        okText="적용"
        cancelText="취소"
        width={760} // 팝업 가로 크기(픽셀 느낌)
      >
        <p className="dim-modal-hint">
          왼쪽: 미노출(숨김) · 오른쪽: 그리드에 노출할 컬럼 (
          <code>DEFAULT_YN=Y</code> 인 항목은 처음에 오른쪽에 둡니다)
        </p>
        {/*
          Transfer:
          - dataSource: 왼쪽+오른쪽에 나올 수 있는 전체 항목 목록
          - targetKeys: “오른쪽에 있는 항목들의 key 배열”
          - onChange: 오른쪽 목록이 바뀌면 부모가 draftRightKeys 를 갱신
          - titles: [왼쪽 제목, 오른쪽 제목]
          - operations: 가운데 버튼 글자(> 는 오른쪽으로 보내기, < 는 왼쪽으로 보내기)
        */}
        <Transfer
          dataSource={dataSource}
          targetKeys={draftRightKeys}
          onChange={handleTransferChange}
          titles={['미노출 (왼쪽)', '노출·그리드 (오른쪽)']}
          operations={['>', '<']}
          listStyle={{ minHeight: 280 }}
        />
      </Modal>
    </div>
  )
}
