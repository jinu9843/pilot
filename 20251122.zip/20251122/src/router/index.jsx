// src/router/index.jsx
import Inventory from "../pages/Inventory";
import Transaction from "../pages/Transaction";

export const routes = [
  { path: "/", element: <Inventory /> },
  { path: "/transaction", element: <Transaction /> }
];
