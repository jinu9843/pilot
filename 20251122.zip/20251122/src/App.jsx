import { Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import { routes } from "./router";

export default function App() {
  return (
    <div className="app-container">
      <div className="app-body">
        <Sidebar />
        <div className="content-wrapper">
          <Header />
          <div className="content">
            <Routes>
              {routes.map(({ path, element }) => (
                <Route key={path} path={path} element={element} />
              ))}
            </Routes>
          </div>
        </div>
      </div>
    </div>
  );
}
