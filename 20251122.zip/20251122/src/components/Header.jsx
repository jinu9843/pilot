import { useNavigate } from "react-router-dom";

export default function Header() {
  const navigate = useNavigate();

  const handleHomeClick = () => {
    navigate("/");
    window.location.reload();
  };

  return (
    <header style={{ padding: "6px 20px", borderBottom: "1px solid #ddd", width: "100%" }}>
      <button onClick={handleHomeClick}>
        홈
      </button>
    </header>
  );
}

