import { useState, useEffect, useRef } from "react";
import dayjs from "dayjs";
import weekOfYear from "dayjs/plugin/weekOfYear";
import isoWeek from "dayjs/plugin/isoWeek";
import { useTranslation } from "react-i18next";
import WeekDatePicker from "./WeekDatePicker";

dayjs.extend(weekOfYear);
dayjs.extend(isoWeek);

export default function InventorySearch({ onFilterChange, onReset }) {
  const { t } = useTranslation();
  const [selectedDate, setSelectedDate] = useState(null);
  const [searchCode, setSearchCode] = useState("");
  const [, setWeek] = useState(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const inputRef = useRef(null);

  // 첫 렌더 시 오늘 날짜로 초기화
  useEffect(() => {
    const today = new Date();
    setSelectedDate(today);
    const currentWeek = dayjs(today).week();
    setWeek(currentWeek);

    // 부모에게도 초기 필터 전달
    onFilterChange(today, "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // 최초 1회 실행

  // 날짜 변경 시
  const handleDateChange = (date) => {
    setSelectedDate(date);
    if (date) {
      const weekNumber = dayjs(date).week();
      setWeek(weekNumber);
    } else {
      setWeek(null);
    }
    onFilterChange(date, searchCode);
  };


  // 년도+주차 형식으로 변환 (예: 202534)
  const getWeekFormat = (date) => {
    if (!date) return "";
    const d = dayjs(date);
    const year = d.year();
    const week = d.isoWeek();
    return `${year}${week.toString().padStart(2, "0")}`;
  };

  // 품목코드 변경 시
  const handleCodeChange = (e) => {
    const code = e.target.value;
    setSearchCode(code);
    onFilterChange(selectedDate, code);
  };

  return (
    <div style={{ marginBottom: 20, position: "relative" }}>
      <div style={{ marginBottom: 10 }}>
        📅 {t("label.weekDate")}:{" "}
        <input
          ref={inputRef}
          type="text"
          placeholder={t("label.weekDate")}
          value={getWeekFormat(selectedDate)}
          readOnly
          onClick={() => setIsCalendarOpen(!isCalendarOpen)}
          style={{ padding: "5px", marginLeft: 5, cursor: "pointer" }}
        />
        <input
          type="text"
          placeholder={t("label.itemCodeSearch")}
          value={searchCode}
          onChange={handleCodeChange}
          style={{ marginLeft: 10, padding: "5px" }}
        />
        <button style={{ marginLeft: 10 }} onClick={onReset}>
          {t("button.all")}
        </button>
      </div>
      {isCalendarOpen && (
        <WeekDatePicker
          selectedDate={selectedDate}
          onChange={handleDateChange}
          isOpen={isCalendarOpen}
          onClose={() => setIsCalendarOpen(false)}
        />
      )}
    </div>
  );
}
