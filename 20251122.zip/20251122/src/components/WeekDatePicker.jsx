import { useState, useEffect, useRef } from "react";
import dayjs from "dayjs";
import weekOfYear from "dayjs/plugin/weekOfYear";
import isoWeek from "dayjs/plugin/isoWeek";
import { useTranslation } from "react-i18next";
import "./WeekDatePicker.css";

dayjs.extend(weekOfYear);
dayjs.extend(isoWeek);

export default function WeekDatePicker({ selectedDate, onChange, isOpen, onClose }) {
  const { i18n } = useTranslation();
  const [currentMonth, setCurrentMonth] = useState(dayjs());
  const [weeks, setWeeks] = useState([]);
  const [currentWeekDates, setCurrentWeekDates] = useState([]);
  const [selectedYear, setSelectedYear] = useState(dayjs().year());
  const [selectedMonth, setSelectedMonth] = useState(dayjs().month() + 1);
  const [selectedWeekNumber, setSelectedWeekNumber] = useState(null);
  const calendarRef = useRef(null);
  const isWeekClickRef = useRef(false); // 주차 클릭 여부 추적

  // 외부 클릭 감지
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen, onClose]);

  // 선택된 날짜가 변경되거나 달력이 열릴 때 currentMonth 업데이트
  useEffect(() => {
    if (selectedDate) {
      const date = dayjs(selectedDate);
      setCurrentMonth(date);
      setSelectedYear(date.year());
      setSelectedMonth(date.month() + 1);
      const startOfWeek = date.startOf("isoWeek");
      const weekDates = [];
      for (let i = 0; i < 7; i++) {
        weekDates.push(startOfWeek.add(i, "day"));
      }
      setCurrentWeekDates(weekDates);
      
      // 주차 클릭과 날짜 클릭을 완전히 분리
      // 날짜 클릭 시에만 주차 선택 해제 (주차 클릭 시에는 유지)
      if (!isWeekClickRef.current) {
        // 날짜 클릭 시: 주차 선택 해제하여 날짜 선택이 정상적으로 표시되도록 함
        setSelectedWeekNumber(null);
      }
      // 플래그는 다음 렌더링 사이클에서 리셋 (비동기 처리)
      setTimeout(() => {
        isWeekClickRef.current = false;
      }, 0);
    } else if (isOpen) {
      // 선택된 날짜가 없고 달력이 열릴 때는 오늘 날짜로
      const today = dayjs();
      setCurrentMonth(today);
      setSelectedYear(today.year());
      setSelectedMonth(today.month() + 1);
      setSelectedWeekNumber(null);
      isWeekClickRef.current = false;
    }
  }, [selectedDate, isOpen]);

  // 년도/월 변경 시 currentMonth 업데이트
  useEffect(() => {
    setCurrentMonth(dayjs(`${selectedYear}-${selectedMonth}-01`));
  }, [selectedYear, selectedMonth]);

  // 월별 주차 목록 생성
  useEffect(() => {
    const monthStart = currentMonth.startOf("month");
    const monthEnd = currentMonth.endOf("month");
    const weeksList = [];
    let currentWeekStart = monthStart.startOf("isoWeek");

    while (currentWeekStart.isBefore(monthEnd) || currentWeekStart.isSame(monthEnd, "month")) {
      const weekDates = [];
      for (let i = 0; i < 7; i++) {
        weekDates.push(currentWeekStart.add(i, "day"));
      }
      const weekNumber = currentWeekStart.isoWeek();
      weeksList.push({
        weekNumber,
        dates: weekDates,
        startDate: currentWeekStart,
      });
      currentWeekStart = currentWeekStart.add(1, "week");
      if (currentWeekStart.isAfter(monthEnd) && !currentWeekStart.isSame(monthEnd, "month")) {
        break;
      }
    }

    setWeeks(weeksList);
  }, [currentMonth]);

  // 1. 날짜 클릭 시: 날짜와 해당 주차에 표시
  const handleDateClick = (date) => {
    isWeekClickRef.current = false; // 날짜 클릭임을 표시
    // 주차 선택 해제를 먼저 수행 (날짜 클릭 시 주차 선택 해제)
    setSelectedWeekNumber(null);
    // 날짜 선택 (부모의 selectedDate 업데이트)
    onChange(date.toDate());
    onClose();
  };

  // 2. 주차 클릭 시: 주차만 표시, 날짜는 표시 안함
  const handleWeekClick = (weekNumber, weekStartDate) => {
    isWeekClickRef.current = true; // 주차 클릭임을 표시
    // 주차 선택 (날짜는 선택하지 않음)
    setSelectedWeekNumber(weekNumber);
    // 인풋값 표시를 위해 날짜 전달 (하지만 날짜는 선택되지 않음 - selectedWeekNumber로 구분)
    // 주차 클릭 시에도 onChange를 호출하되, selectedWeekNumber가 설정되어 있으므로 날짜는 선택되지 않음
    onChange(weekStartDate.toDate());
    onClose();
  };

  const handlePrevMonth = () => {
    const newMonth = currentMonth.subtract(1, "month");
    setCurrentMonth(newMonth);
    setSelectedYear(newMonth.year());
    setSelectedMonth(newMonth.month() + 1);
  };

  const handleNextMonth = () => {
    const newMonth = currentMonth.add(1, "month");
    setCurrentMonth(newMonth);
    setSelectedYear(newMonth.year());
    setSelectedMonth(newMonth.month() + 1);
  };

  const handleYearChange = (e) => {
    setSelectedYear(parseInt(e.target.value));
  };

  const handleMonthChange = (e) => {
    setSelectedMonth(parseInt(e.target.value));
  };

  // 년도 옵션 생성 (-15년 ~ +15년)
  const currentYear = dayjs().year();
  const yearOptions = [];
  for (let i = currentYear - 15; i <= currentYear + 15; i++) {
    yearOptions.push(i);
  }

  // 월 옵션 생성
  const monthOptions = [];
  const monthNames = i18n.language === "en"
    ? ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    : ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
  for (let i = 1; i <= 12; i++) {
    monthOptions.push({ value: i, label: monthNames[i - 1] });
  }

  const isToday = (date) => {
    return date.isSame(dayjs(), "day");
  };

  const isSelected = (date) => {
    // 주차 선택과 날짜 선택을 완전히 분리
    // 주차 클릭 시: 주차만 표시, 날짜는 표시 안함
    // 주차가 선택된 경우 날짜는 절대 선택되지 않음
    if (selectedWeekNumber !== null) {
      return false;
    }
    // 1. 날짜 클릭 시: 날짜와 해당 주차에 표시
    if (!selectedDate) return false;
    // selectedDate와 비교하여 날짜 선택 확인
    return date.isSame(dayjs(selectedDate), "day");
  };

  const isCurrentWeek = (weekDates, weekNumber) => {
    // 2. 주차 클릭 시: 주차만 표시
    if (selectedWeekNumber !== null) {
      return selectedWeekNumber === weekNumber;
    }
    // 1. 날짜 클릭 시: 날짜와 해당 주차에 표시
    if (!selectedDate) return false;
    const selected = dayjs(selectedDate);
    return weekDates.some((d) => d.isSame(selected, "day"));
  };

  const weekDayNames =
    i18n.language === "en"
      ? ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
      : ["일", "월", "화", "수", "목", "금", "토"];

  if (!isOpen) return null;

  return (
    <div className="week-date-picker" ref={calendarRef}>
      <div className="week-date-picker-header">
        <button onClick={handlePrevMonth}>‹</button>
        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
          <select
            value={selectedYear}
            onChange={handleYearChange}
            style={{ padding: "4px", border: "1px solid #ddd", borderRadius: "4px" }}
          >
            {yearOptions.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
          <select
            value={selectedMonth}
            onChange={handleMonthChange}
            style={{ padding: "4px", border: "1px solid #ddd", borderRadius: "4px" }}
          >
            {monthOptions.map((month) => (
              <option key={month.value} value={month.value}>
                {month.label}
              </option>
            ))}
          </select>
        </div>
        <button onClick={handleNextMonth}>›</button>
      </div>

      <div className="week-date-picker-table">
        <div className="week-date-picker-header-row">
          <div className="week-header-cell">주차</div>
          {weekDayNames.map((day, idx) => (
            <div key={idx} className="day-header-cell">
              {day}
            </div>
          ))}
        </div>

        {weeks.map((week, weekIdx) => {
          const isHighlighted = isCurrentWeek(week.dates, week.weekNumber);
          return (
            <div
              key={weekIdx}
              className={`week-date-picker-row ${isHighlighted ? "current-week" : ""}`}
            >
              <div
                className={`week-number-cell ${isHighlighted ? "selected-week" : ""}`}
                onClick={() => handleWeekClick(week.weekNumber, week.dates[0])}
                style={{ cursor: "pointer" }}
              >
                {week.weekNumber}주
              </div>
              {week.dates.map((date, dayIdx) => {
                const isInMonth = date.isSame(currentMonth, "month");
                const isTodayDate = isToday(date);
                // 날짜 클릭 시: 날짜와 해당 주차에 표시
                // 주차 클릭 시: 주차만 표시, 날짜는 표시 안함 (selectedWeekNumber !== null이면 날짜 선택 안됨)
                // 주차 번호로 선택된 경우에는 날짜를 절대 선택하지 않음
                const isSelectedDate = selectedWeekNumber === null && isSelected(date);
                // 주차 번호로 선택된 경우를 표시 (CSS에서 날짜 셀의 selected 스타일을 무시하기 위해)
                const isWeekSelected = isHighlighted && selectedWeekNumber !== null;

                return (
                  <div
                    key={dayIdx}
                    className={`date-cell ${!isInMonth ? "other-month" : ""} ${
                      isTodayDate ? "today" : ""
                    } ${isSelectedDate ? "selected" : ""} ${isWeekSelected ? "week-selected" : ""}`}
                    onClick={() => handleDateClick(date)}
                  >
                    {date.format("D")}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      {currentWeekDates.length > 0 && (
        <div className="current-week-info">
          <strong>
            {i18n.language === "en" ? "Selected Week:" : "현재 선택된 주차:"}
          </strong>{" "}
          {currentWeekDates[0].format("YYYY-MM-DD")} ~{" "}
          {currentWeekDates[6].format("YYYY-MM-DD")}
        </div>
      )}
    </div>
  );
}
