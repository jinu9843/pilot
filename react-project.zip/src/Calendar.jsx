import React, { useState, useRef, useEffect } from 'react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  addMonths, 
  subMonths, 
  getISOWeek, 
  isSameMonth,
  isSameDay,
  setYear,
  setMonth
} from 'date-fns';
import styles from './Calendar.module.css';

const Calendar = () => {
  const getWeekValue = (day) => {
    // 1. Find the Thursday of the week (assuming Sunday start)
    // Sunday (0) -> +4 days -> Thursday
    // Monday (1) -> +3 days -> Thursday
    // ...
    // Saturday (6) -> -2 days -> Thursday
    const thursday = new Date(day);
    thursday.setDate(day.getDate() + (4 - day.getDay()));
    
    const year = thursday.getFullYear();
    const week = getISOWeek(thursday);
    const weekString = week.toString().padStart(2, '0');
    
    return `${year}${weekString}`;
  };

  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedWeek, setSelectedWeek] = useState(() => getWeekValue(new Date()));
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [highlightedDate, setHighlightedDate] = useState(new Date());
  const [isOpen, setIsOpen] = useState(false);
  const [isYearOpen, setIsYearOpen] = useState(false);
  const [isMonthOpen, setIsMonthOpen] = useState(false);
  const calendarRef = useRef(null);

  // Close calendar when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target)) {
        setIsOpen(false);
        setIsYearOpen(false);
        setIsMonthOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const nextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const prevMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const handleDateClick = (day) => {
    setSelectedWeek(getWeekValue(day));
    setHighlightedDate(day); // Highlight the specific date
    
    // Switch calendar view to the month of the selected week (using Thursday as anchor)
    const thursday = new Date(day);
    thursday.setDate(day.getDate() + (4 - day.getDay()));
    setCurrentDate(thursday);

    setIsOpen(false); // Close calendar after selection
  };
  
  const handleWeekClick = (weekValue) => {
    setSelectedWeek(weekValue);
    setHighlightedDate(null); // Clear the blue date highlight
    setIsOpen(false);
  };

  const toggleCalendar = () => {
    setIsOpen(!isOpen);
  };

  const handleYearClick = (year) => {
    setCurrentDate(setYear(currentDate, year));
    setIsYearOpen(false);
  };

  const handleMonthClick = (month) => {
    setCurrentDate(setMonth(currentDate, month - 1));
    setIsMonthOpen(false);
  };

  // Generate years for dropdown (current year is start, show next 15 years)
  const currentYear = currentDate.getFullYear();
  // Generate a wider range of years so user can scroll up/down, 
  // but we will scroll to the current year at the top.
  const years = Array.from({ length: 200 }, (_, i) => 1900 + i);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);

  // Refs for dropdowns to handle scrolling
  const yearDropdownRef = useRef(null);
  const monthDropdownRef = useRef(null);

  useEffect(() => {
    if (isYearOpen && yearDropdownRef.current) {
      const selectedYearEl = yearDropdownRef.current.querySelector(`.${styles['selected-item']}`);
      if (selectedYearEl) {
        selectedYearEl.scrollIntoView({ block: 'start' });
      }
    }
  }, [isYearOpen]);

  useEffect(() => {
    if (isMonthOpen && monthDropdownRef.current) {
      const selectedMonthEl = monthDropdownRef.current.querySelector(`.${styles['selected-item']}`);
      if (selectedMonthEl) {
        selectedMonthEl.scrollIntoView({ block: 'start' });
      }
    }
  }, [isMonthOpen]);


  // Generate the calendar grid
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 0 }); 
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 0 }); 

  const calendarDays = eachDayOfInterval({
    start: startDate,
    end: endDate,
  });

  const weeks = [];
  let week = [];
  calendarDays.forEach((day) => {
    week.push(day);
    if (week.length === 7) {
      weeks.push(week);
      week = [];
    }
  });

  const weekHeaders = ['주차', '일', '월', '화', '수', '목', '금', '토'];

  return (
    <div className={styles['calendar-wrapper']} ref={calendarRef}>
      <div className={styles['input-container']} onClick={toggleCalendar}>
        <input 
          type="text" 
          value={selectedWeek} 
          readOnly 
          placeholder="주차 선택"
          className={styles['calendar-input']} 
        />
      </div>

      {isOpen && (
        <div className={styles['calendar-popup']}>
          <div className={styles['calendar-container']}>
            <div className={styles['header-controls']}>
              <button onClick={prevMonth}>&lt;</button>
              <div className={styles['header-title']}>
                <div className={styles['dropdown-container']}>
                  <span onClick={() => { setIsYearOpen(!isYearOpen); setIsMonthOpen(false); }} className={styles['header-clickable']}>
                    {format(currentDate, 'yyyy년')}
                  </span>
                  {isYearOpen && (
                    <div className={`${styles['dropdown-menu']} ${styles['year-dropdown']}`} ref={yearDropdownRef}>
                      {years.map(year => (
                        <div 
                          key={year} 
                          className={`${styles['dropdown-item']} ${year === currentDate.getFullYear() ? styles['selected-item'] : ''}`}
                          onClick={() => handleYearClick(year)}
                        >
                          {year}년
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className={styles['dropdown-container']}>
                  <span onClick={() => { setIsMonthOpen(!isMonthOpen); setIsYearOpen(false); }} className={styles['header-clickable']}>
                    {format(currentDate, 'M월')}
                  </span>
                  {isMonthOpen && (
                    <div className={`${styles['dropdown-menu']} ${styles['month-dropdown']}`} ref={monthDropdownRef}>
                      {months.map(month => (
                        <div 
                          key={month} 
                          className={`${styles['dropdown-item']} ${month === currentDate.getMonth() + 1 ? styles['selected-item'] : ''}`}
                          onClick={() => handleMonthClick(month)}
                        >
                          {month}월
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <button onClick={nextMonth}>&gt;</button>
            </div>

            <div className={styles['calendar-grid']}>
              {weekHeaders.map((header) => (
                <div key={header} className={`${styles['calendar-cell']} ${styles['header-cell']}`}>
                  {header}
                </div>
              ))}

              {weeks.map((weekDays, weekIndex) => {
                const thursdayOfWeek = weekDays[4];
                const weekNumber = getISOWeek(thursdayOfWeek);
                const weekYear = thursdayOfWeek.getFullYear();
                const weekValue = `${weekYear}${weekNumber.toString().padStart(2, '0')}`;
                
                const isSelectedWeek = weekValue === selectedWeek;

                return (
                  <React.Fragment key={weekIndex}>
                    <div 
                      className={`${styles['calendar-cell']} ${styles['week-number-cell']} ${isSelectedWeek ? styles['selected-week-number'] : ''}`}
                      onClick={() => handleWeekClick(weekValue)}
                    >
                      {weekNumber}
                    </div>
                    {weekDays.map((day) => (
                      <div 
                        key={day.toISOString()} 
                        className={`${styles['calendar-cell']} ${styles['day-cell']} ${
                          !isSameMonth(day, monthStart) ? styles['not-current-month'] : ''
                        } ${isSameDay(day, new Date()) ? styles['today'] : ''} ${
                          highlightedDate && isSameDay(day, highlightedDate) ? styles['selected'] : ''
                        }`}
                        onClick={() => handleDateClick(day)}
                      >
                        {format(day, 'd')}
                      </div>
                    ))}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Calendar;
