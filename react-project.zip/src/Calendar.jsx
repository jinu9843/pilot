import React, { useState, useRef, useEffect } from 'react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  addMonths, 
  subMonths, 
  getISOWeek, 
  isSameMonth,
  isSameDay,
  setYear,
  setMonth
} from 'date-fns';
import './Calendar.css';

const Calendar = () => {
  const getWeekValue = (day) => {
    // 1. Find the Thursday of the week (assuming Sunday start)
    // Sunday (0) -> +4 days -> Thursday
    // Monday (1) -> +3 days -> Thursday
    // ...
    // Saturday (6) -> -2 days -> Thursday
    const thursday = new Date(day);
    thursday.setDate(day.getDate() + (4 - day.getDay()));
    
    const year = thursday.getFullYear();
    const week = getISOWeek(thursday);
    const weekString = week.toString().padStart(2, '0');
    
    return `${year}${weekString}`;
  };

  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedWeek, setSelectedWeek] = useState(() => getWeekValue(new Date()));
  const [selectedDate, setSelectedDate] = useState(new Date());
  // We'll use null to indicate no specific date is selected (only week selected)
  // or we can just use a separate state 'isDateSelected' to track if the highlight should be shown.
  // Actually, the requirement says: "If date clicked -> show blue. Then if week clicked -> show red arrow AND clear blue."
  // So we can just set selectedDate to null or a non-matching value.
  const [highlightedDate, setHighlightedDate] = useState(new Date());
  const [isOpen, setIsOpen] = useState(false);
  const [isYearOpen, setIsYearOpen] = useState(false);
  const [isMonthOpen, setIsMonthOpen] = useState(false);
  const calendarRef = useRef(null);

  // Close calendar when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (calendarRef.current && !calendarRef.current.contains(event.target)) {
        setIsOpen(false);
        setIsYearOpen(false);
        setIsMonthOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const nextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const prevMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const handleDateClick = (day) => {
    setSelectedWeek(getWeekValue(day));
    setHighlightedDate(day); // Highlight the specific date
    
    // Switch calendar view to the month of the selected week (using Thursday as anchor)
    const thursday = new Date(day);
    thursday.setDate(day.getDate() + (4 - day.getDay()));
    setCurrentDate(thursday);

    // Keep calendar open to allow week selection if desired, or close? 
    // Requirement: "Date click -> Blue highlight. Then week click -> Red arrow & Clear blue."
    // This implies the calendar stays open or re-opens? 
    // Usually date click closes the calendar.
    // If date click closes calendar, user has to open it again to click week.
    // Let's assume standard behavior: Date click -> Set value & Close.
    // But if they want to click week *after*, they open it again.
    // Let's keep the close behavior for now.
    setIsOpen(false); 
  };
  
  const handleWeekClick = (weekValue) => {
    setSelectedWeek(weekValue);
    setHighlightedDate(null); // Clear the blue date highlight
    setIsOpen(false);
  };

  const toggleCalendar = () => {
    setIsOpen(!isOpen);
  };

  const handleYearClick = (year) => {
    setCurrentDate(setYear(currentDate, year));
    setIsYearOpen(false);
  };

  const handleMonthClick = (month) => {
    setCurrentDate(setMonth(currentDate, month - 1));
    setIsMonthOpen(false);
  };

  // Generate years for dropdown (current year is start, show next 15 years)
  const currentYear = currentDate.getFullYear();
  // Generate a wider range of years so user can scroll up/down, 
  // but we will scroll to the current year at the top.
  const years = Array.from({ length: 200 }, (_, i) => 1900 + i);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);

  // Refs for dropdowns to handle scrolling
  const yearDropdownRef = useRef(null);
  const monthDropdownRef = useRef(null);

  useEffect(() => {
    if (isYearOpen && yearDropdownRef.current) {
      const selectedYearEl = yearDropdownRef.current.querySelector('.selected-item');
      if (selectedYearEl) {
        selectedYearEl.scrollIntoView({ block: 'start' });
      }
    }
  }, [isYearOpen]);

  useEffect(() => {
    if (isMonthOpen && monthDropdownRef.current) {
      const selectedMonthEl = monthDropdownRef.current.querySelector('.selected-item');
      if (selectedMonthEl) {
        selectedMonthEl.scrollIntoView({ block: 'start' });
      }
    }
  }, [isMonthOpen]);


  // Generate the calendar grid
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 0 }); 
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 0 }); 

  const calendarDays = eachDayOfInterval({
    start: startDate,
    end: endDate,
  });

  const weeks = [];
  let week = [];
  calendarDays.forEach((day) => {
    week.push(day);
    if (week.length === 7) {
      weeks.push(week);
      week = [];
    }
  });

  const weekHeaders = ['주차', '일', '월', '화', '수', '목', '금', '토'];

  return (
    <div className="calendar-wrapper" ref={calendarRef}>
      <div className="input-container" onClick={toggleCalendar}>
        <label style={{ fontWeight: 'bold' }}>주차 달력</label>
        <input 
          type="text" 
          value={selectedWeek} 
          readOnly 
          placeholder="날짜 선택"
          style={{ 
            padding: '8px', 
            fontSize: '16px', 
            borderRadius: '4px', 
            border: '1px solid #ccc',
            width: '120px',
            cursor: 'pointer'
          }}
        />
      </div>

      {isOpen && (
        <div className="calendar-popup">
          <div className="calendar-container">
            <div className="header-controls">
              <button onClick={prevMonth}>&lt;</button>
              <div className="header-title">
                <div className="dropdown-container">
                  <span onClick={() => { setIsYearOpen(!isYearOpen); setIsMonthOpen(false); }} className="header-clickable">
                    {format(currentDate, 'yyyy년')}
                  </span>
                  {isYearOpen && (
                    <div className="dropdown-menu year-dropdown" ref={yearDropdownRef}>
                      {years.map(year => (
                        <div 
                          key={year} 
                          className={`dropdown-item ${year === currentDate.getFullYear() ? 'selected-item' : ''}`}
                          onClick={() => handleYearClick(year)}
                        >
                          {year}년
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="dropdown-container">
                  <span onClick={() => { setIsMonthOpen(!isMonthOpen); setIsYearOpen(false); }} className="header-clickable">
                    {format(currentDate, 'M월')}
                  </span>
                  {isMonthOpen && (
                    <div className="dropdown-menu month-dropdown" ref={monthDropdownRef}>
                      {months.map(month => (
                        <div 
                          key={month} 
                          className={`dropdown-item ${month === currentDate.getMonth() + 1 ? 'selected-item' : ''}`}
                          onClick={() => handleMonthClick(month)}
                        >
                          {month}월
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <button onClick={nextMonth}>&gt;</button>
            </div>

            <div className="calendar-grid">
              {weekHeaders.map((header) => (
                <div key={header} className="calendar-cell header-cell">
                  {header}
                </div>
              ))}

              {weeks.map((weekDays, weekIndex) => {
                const thursdayOfWeek = weekDays[4];
                const weekNumber = getISOWeek(thursdayOfWeek);
                const weekYear = thursdayOfWeek.getFullYear();
                const weekValue = `${weekYear}${weekNumber.toString().padStart(2, '0')}`;
                
                const isSelectedWeek = weekValue === selectedWeek;

                return (
                  <React.Fragment key={weekIndex}>
                    <div 
                      className={`calendar-cell week-number-cell ${isSelectedWeek ? 'selected-week-number' : ''}`}
                      onClick={() => handleWeekClick(weekValue)}
                    >
                      {weekNumber}
                    </div>
                    {weekDays.map((day) => (
                      <div 
                        key={day.toISOString()} 
                        className={`calendar-cell day-cell ${
                          !isSameMonth(day, monthStart) ? 'not-current-month' : ''
                        } ${isSameDay(day, new Date()) ? 'today' : ''} ${
                          highlightedDate && isSameDay(day, highlightedDate) ? 'selected' : ''
                        }`}
                        onClick={() => handleDateClick(day)}
                      >
                        {format(day, 'd')}
                      </div>
                    ))}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Calendar;

