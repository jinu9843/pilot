# Java Debug → Swagger JSON 변환기

## 실행 방법

1. **`실행.bat`** 더블클릭 (가장 쉬움)
2. 또는 **`index.html`** 을 브라우저로 직접 열기

## 사용법

1. Java 디버그에서 복사한 값을 왼쪽 입력창에 붙여넣기
2. **변환** 클릭
3. 오른쪽 Swagger JSON **복사** 후 Swagger Request Body에 붙여넣기

## 입력 예시

```
sort_cnt ={0}
pri_user_id={<null>}
sale_typ={}
rnd_unit={1}
```

## 출력 예시

```json
{
  "sortCnt": "0",
  "saleTyp": "",
  "rndUnit": "1",
  "periodFrom": "202601",
  "periodTo": "202606"
}
```

## 변환 규칙

| 입력 | 출력 |
|---|---|
| `sort_cnt ={0}` | `"sortCnt": "0"` |
| `pri_user_id={<null>}` | null (기본: JSON에서 제외) |
| `sale_typ={}` | `"saleTyp": ""` |
| `rnd_unit={1}` | `"rndUnit": "1"` |
| snake_case | camelCase |

## 옵션

- **숫자는 JSON number로**: `0` → `"sortCnt": 0` (따옴표 없음)
- **null 필드는 JSON에서 제외**: `<null>` 값은 Swagger JSON에 넣지 않음

## 위치

`C:\Users\sunshine\Desktop\debug-to-swagger\`
