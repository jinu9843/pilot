(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.NexacroSpringbootGenerator = factory();
  }
})(typeof self !== "undefined" ? self : this, function () {
  const MYBATIS_DOCTYPE =
    '<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "https://mybatis.org/dtd/mybatis-3-mapper.dtd">';

  function unique(array) {
    return Array.from(new Set(array));
  }

  function toWords(value) {
    return String(value || "")
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .replace(/[^A-Za-z0-9]+/g, " ")
      .trim()
      .split(/\s+/)
      .filter(Boolean);
  }

  function capitalize(word) {
    const lower = String(word || "").toLowerCase();
    return lower.charAt(0).toUpperCase() + lower.slice(1);
  }

  function toPascalCase(value) {
    const words = toWords(value);
    if (words.length === 0) {
      return "Generated";
    }

    return words.map(capitalize).join("");
  }

  function toCamelCase(value) {
    const pascal = toPascalCase(value);
    return pascal.charAt(0).toLowerCase() + pascal.slice(1);
  }

  function toKebabCase(value) {
    const words = toWords(value);
    if (words.length === 0) {
      return "generated";
    }

    return words.map(function (word) {
      return String(word).toLowerCase();
    }).join("-");
  }

  function toPackageSegment(value) {
    const words = toWords(value);
    if (words.length === 0) {
      return "generated";
    }

    return words.map(function (word) {
      return String(word).toLowerCase();
    }).join("");
  }

  function parseAttributes(attributeText) {
    const attributes = {};
    const regex = /([A-Za-z_:][\w:.-]*)\s*=\s*(['"])(.*?)\2/g;
    let match = regex.exec(attributeText || "");

    while (match) {
      attributes[match[1]] = match[3];
      match = regex.exec(attributeText || "");
    }

    return attributes;
  }

  function buildAttributeString(attributes, preferredOrder) {
    const keys = Object.keys(attributes || {});
    const ordered = [];
    const used = {};

    (preferredOrder || []).forEach(function (key) {
      if (Object.prototype.hasOwnProperty.call(attributes, key) && attributes[key] !== "") {
        ordered.push(key);
        used[key] = true;
      }
    });

    keys.forEach(function (key) {
      if (!used[key] && attributes[key] !== "") {
        ordered.push(key);
      }
    });

    return ordered.map(function (key) {
      return ' ' + key + '="' + String(attributes[key]).replace(/"/g, "&quot;") + '"';
    }).join("");
  }

  function isBlank(value) {
    return String(value || "").trim() === "";
  }

  function looksLikeJavaType(token) {
    return /^(String|Integer|Long|Double|Float|Boolean|BigDecimal|LocalDate|LocalDateTime|List<.*>|Map<.*>|HashMap<.*>|int|long|double|float|boolean|BigDecimal|Date|Timestamp)$/i.test(
      String(token || "").trim()
    );
  }

  function normalizeComment(line) {
    return String(line || "")
      .replace(/\/\/.*$/, "")
      .replace(/#.*$/, "")
      .trim();
  }

  function stripQuotes(value) {
    return String(value || "").replace(/^['"]|['"]$/g, "");
  }

  function inferJavaType(rawType, sampleValue, options) {
    const raw = String(rawType || "").trim().toLowerCase();
    const sample = stripQuotes(sampleValue).trim();
    const dateType = (options && options.dateType) || "String";

    if (raw) {
      if (/bigdecimal|decimal|numeric|number\(.*,\s*[1-9]\d*\)/i.test(raw)) {
        return "BigDecimal";
      }
      if (/bigint|long/i.test(raw)) {
        return "Long";
      }
      if (/int|integer|short|number/i.test(raw) && !/point|decimal/i.test(raw)) {
        return "Integer";
      }
      if (/double|float/i.test(raw)) {
        return "Double";
      }
      if (/bool/i.test(raw)) {
        return "Boolean";
      }
      if (/timestamp|datetime/i.test(raw)) {
        return dateType === "LocalDateTime" ? "LocalDateTime" : "String";
      }
      if (/date|time/i.test(raw)) {
        if (dateType === "LocalDateTime") {
          return "LocalDateTime";
        }
        if (dateType === "LocalDate") {
          return "LocalDate";
        }
        return "String";
      }
      if (/char|string|text|varchar|nvarchar|clob|blob|map|object/i.test(raw)) {
        return "String";
      }
    }

    if (/^(true|false)$/i.test(sample)) {
      return "Boolean";
    }

    if (/^-?\d+$/.test(sample)) {
      return sample.length > 9 ? "Long" : "Integer";
    }

    if (/^-?\d+\.\d+$/.test(sample)) {
      return "BigDecimal";
    }

    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(sample)) {
      return dateType === "LocalDateTime" ? "LocalDateTime" : "String";
    }

    if (/^\d{4}-\d{2}-\d{2}$/.test(sample) || /^\d{8}$/.test(sample)) {
      if (dateType === "LocalDateTime") {
        return "LocalDateTime";
      }
      if (dateType === "LocalDate") {
        return "LocalDate";
      }
      return "String";
    }

    return "String";
  }

  function createField(rawName, rawType, sampleValue, options) {
    const safeName = String(rawName || "").trim();
    if (!safeName) {
      return null;
    }

    return {
      rawName: safeName,
      javaName: toCamelCase(safeName),
      javaType: inferJavaType(rawType, sampleValue, options),
      rawType: String(rawType || "").trim(),
      sampleValue: stripQuotes(sampleValue || ""),
    };
  }

  function parseFieldLine(line, options) {
    const cleaned = normalizeComment(line);
    if (!cleaned) {
      return null;
    }

    let match = cleaned.match(
      /<\s*(?:Column|column|col|Field|field|Parameter|parameter)\b[^>]*(?:id|name)=["']([^"']+)["'][^>]*(?:type|dataType|datatype)=["']([^"']+)["'][^>]*\/?>/i
    );
    if (match) {
      return createField(match[1], match[2], "", options);
    }

    match = cleaned.match(
      /<\s*(?:Column|column|col|Field|field|Parameter|parameter)\b[^>]*(?:id|name)=["']([^"']+)["'][^>]*\/?>/i
    );
    if (match) {
      return createField(match[1], "", "", options);
    }

    match = cleaned.match(
      /^(?:private|protected|public)?\s*(?:static\s+)?(?:final\s+)?([A-Za-z_][\w<>.?]*)\s+([A-Za-z_][\w]*)\s*;?$/
    );
    if (match) {
      return createField(match[2], match[1], "", options);
    }

    match = cleaned.match(/^["']?([A-Za-z_][\w-]*)["']?\s*:\s*(.+)$/);
    if (match) {
      const rhs = match[2].trim();
      const rhsToken = rhs.replace(/[,;]$/, "").trim();
      const rhsIsType = looksLikeJavaType(rhsToken) || /^[A-Z_]+$/.test(rhsToken);
      return createField(match[1], rhsIsType ? rhsToken : "", rhsIsType ? "" : rhsToken, options);
    }

    match = cleaned.match(/^([A-Za-z_][\w-]*)\s*=\s*(.+)$/);
    if (match) {
      return createField(match[1], "", match[2].replace(/[,;]$/, "").trim(), options);
    }

    match = cleaned.match(/^([A-Za-z_][\w-]*)\s+([A-Za-z_][\w<>.?]*)$/);
    if (match) {
      if (looksLikeJavaType(match[1])) {
        return createField(match[2], match[1], "", options);
      }
      if (looksLikeJavaType(match[2]) || /^[A-Z_]+$/.test(match[2])) {
        return createField(match[1], match[2], "", options);
      }
    }

    match = cleaned.match(/^([A-Za-z_][\w-]*)$/);
    if (match) {
      return createField(match[1], "", "", options);
    }

    return null;
  }

  function parseFieldText(text, options, warnings, label) {
    const lines = String(text || "").split(/\r?\n/);
    const fields = [];
    const seen = {};

    lines.forEach(function (line) {
      const field = parseFieldLine(line, options);
      if (!field) {
        return;
      }

      if (!seen[field.javaName]) {
        fields.push(field);
        seen[field.javaName] = true;
      }
    });

    if (!isBlank(text) && fields.length === 0) {
      warnings.push(label + "에서 필드를 해석하지 못했습니다. 한 줄에 한 항목씩 붙여넣어 주세요.");
    }

    return fields;
  }

  function parseServiceMethod(serviceSource) {
    const source = String(serviceSource || "");
    const regex =
      /^\s*(?:@\w+(?:\([^)]*\))?\s*)*(?:public|protected|private)?\s*(?:static\s+)?([\w<>\[\], ?.$]+)\s+([A-Za-z_]\w*)\s*\(([^)]*)\)/m;
    const match = source.match(regex);

    if (!match) {
      return {
        methodName: "",
        returnTypeRaw: "",
        parametersRaw: "",
      };
    }

    return {
      returnTypeRaw: match[1].replace(/\s+/g, " ").trim(),
      methodName: match[2].trim(),
      parametersRaw: match[3].trim(),
    };
  }

  function parseSqlMeta(xmlSource) {
    const source = String(xmlSource || "");
    const regex = /<\s*(select|insert|update|delete)\b([^>]*)>/gi;
    const statements = [];
    let match = regex.exec(source);

    while (match) {
      statements.push({
        action: match[1].toLowerCase(),
        attrs: parseAttributes(match[2] || ""),
      });
      match = regex.exec(source);
    }

    return {
      statements: statements,
      first: statements[0] || null,
    };
  }

  function inferAction(methodName, sqlMeta, actionOption) {
    if (actionOption && actionOption !== "auto") {
      return actionOption;
    }

    const sqlAction = sqlMeta && sqlMeta.first ? sqlMeta.first.action : "";
    if (sqlAction) {
      return sqlAction;
    }

    const name = String(methodName || "").toLowerCase();
    if (/^(save|insert|add|create|regist)/.test(name)) {
      return "insert";
    }
    if (/^(update|modify|change)/.test(name)) {
      return "update";
    }
    if (/^(delete|remove)/.test(name)) {
      return "delete";
    }
    return "select";
  }

  function inferResponseMode(action, responseOption, serviceMeta) {
    if (responseOption && responseOption !== "auto") {
      return responseOption;
    }

    if (action !== "select") {
      return "int";
    }

    const returnType = String((serviceMeta && serviceMeta.returnTypeRaw) || "");
    if (/List<|Collection<|DataSetMap/i.test(returnType)) {
      return "list";
    }

    return "list";
  }

  function guessFeatureName(featureName, serviceMeta, sqlMeta) {
    if (!isBlank(featureName)) {
      return toPascalCase(featureName);
    }

    if (serviceMeta && serviceMeta.methodName) {
      return toPascalCase(serviceMeta.methodName.replace(/^(get|search|select|save|insert|update|delete|list)/i, ""));
    }

    if (sqlMeta && sqlMeta.first && sqlMeta.first.attrs.id) {
      return toPascalCase(sqlMeta.first.attrs.id);
    }

    return "Generated";
  }

  function guessMethodName(serviceMeta, sqlMeta, featureClassName, action, responseMode) {
    if (serviceMeta && serviceMeta.methodName) {
      return serviceMeta.methodName;
    }

    if (sqlMeta && sqlMeta.first && sqlMeta.first.attrs.id) {
      return sqlMeta.first.attrs.id;
    }

    if (action === "select" && responseMode === "list") {
      return "get" + featureClassName + "List";
    }
    if (action === "select") {
      return "get" + featureClassName;
    }
    if (action === "insert") {
      return "save" + featureClassName;
    }
    if (action === "update") {
      return "update" + featureClassName;
    }
    return "delete" + featureClassName;
  }

  function buildClassNames(featureClassName) {
    return {
      featureClassName: featureClassName,
      requestDto: featureClassName + "RequestDto",
      responseDto: featureClassName + "ResponseDto",
      service: featureClassName + "Service",
      serviceImpl: featureClassName + "ServiceImpl",
      mapper: featureClassName + "Mapper",
      controller: featureClassName + "Controller",
    };
  }

  function buildPackages(basePackage, featureClassName) {
    const root = String(basePackage || "com.example.demo").trim();
    const featurePackage = toPackageSegment(featureClassName);

    return {
      root: root,
      dto: root + "." + featurePackage + ".dto",
      service: root + "." + featurePackage + ".service",
      impl: root + "." + featurePackage + ".service.impl",
      mapper: root + "." + featurePackage + ".mapper",
      controller: root + "." + featurePackage + ".controller",
    };
  }

  function getReturnType(responseMode, classNames) {
    if (responseMode === "single") {
      return classNames.responseDto;
    }
    if (responseMode === "void") {
      return "void";
    }
    if (responseMode === "int") {
      return "int";
    }
    return "List<" + classNames.responseDto + ">";
  }

  function collectTypeImports(fields) {
    const imports = [];

    fields.forEach(function (field) {
      if (field.javaType === "BigDecimal") {
        imports.push("java.math.BigDecimal");
      }
      if (field.javaType === "LocalDate") {
        imports.push("java.time.LocalDate");
      }
      if (field.javaType === "LocalDateTime") {
        imports.push("java.time.LocalDateTime");
      }
    });

    return unique(imports).sort();
  }

  function generateDto(packageName, className, fields) {
    const imports = collectTypeImports(fields);
    const importLines = []
      .concat(imports)
      .concat([
        "lombok.AllArgsConstructor",
        "lombok.Builder",
        "lombok.Getter",
        "lombok.NoArgsConstructor",
        "lombok.Setter",
      ])
      .map(function (line) {
        return "import " + line + ";";
      })
      .join("\n");

    const body = fields.length > 0
      ? fields.map(function (field) {
          return "    private " + field.javaType + " " + field.javaName + ";";
        }).join("\n")
      : "    // TODO: 필드를 확인해 주세요.";

    return [
      "package " + packageName + ";",
      "",
      importLines,
      "",
      "@Getter",
      "@Setter",
      "@Builder",
      "@NoArgsConstructor",
      "@AllArgsConstructor",
      "public class " + className + " {",
      body,
      "}",
      "",
    ].join("\n");
  }

  function generateService(packages, classNames, methodName, responseMode) {
    const lines = [
      "package " + packages.service + ";",
      "",
      "import " + packages.dto + "." + classNames.requestDto + ";",
    ];

    if (responseMode === "list" || responseMode === "single") {
      lines.push("import " + packages.dto + "." + classNames.responseDto + ";");
    }
    if (responseMode === "list") {
      lines.push("import java.util.List;");
    }

    lines.push(
      "",
      "public interface " + classNames.service + " {",
      "    " + getReturnType(responseMode, classNames) + " " + methodName + "(" + classNames.requestDto + " requestDto);",
      "}",
      ""
    );

    return lines.join("\n");
  }

  function generateServiceImpl(packages, classNames, methodName, responseMode, action) {
    const lines = [
      "package " + packages.impl + ";",
      "",
      "import " + packages.dto + "." + classNames.requestDto + ";",
    ];

    if (responseMode === "list" || responseMode === "single") {
      lines.push("import " + packages.dto + "." + classNames.responseDto + ";");
    }
    lines.push(
      "import " + packages.mapper + "." + classNames.mapper + ";",
      "import " + packages.service + "." + classNames.service + ";",
      "import lombok.RequiredArgsConstructor;",
      "import org.springframework.stereotype.Service;",
      "import org.springframework.transaction.annotation.Transactional;"
    );
    if (responseMode === "list") {
      lines.push("import java.util.List;");
    }

    const bodyLines = [];
    if (responseMode === "void") {
      bodyLines.push("        " + toCamelCase(classNames.mapper) + "." + methodName + "(requestDto);");
    } else {
      bodyLines.push("        return " + toCamelCase(classNames.mapper) + "." + methodName + "(requestDto);");
    }

    lines.push(
      "",
      "@Service",
      "@RequiredArgsConstructor",
      "@Transactional(readOnly = " + (action === "select" ? "true" : "false") + ")",
      "public class " + classNames.serviceImpl + " implements " + classNames.service + " {",
      "    private final " + classNames.mapper + " " + toCamelCase(classNames.mapper) + ";",
      "",
      "    @Override",
      "    public " + getReturnType(responseMode, classNames) + " " + methodName + "(" + classNames.requestDto + " requestDto) {",
      bodyLines.join("\n"),
      "    }",
      "}",
      ""
    );

    return lines.join("\n");
  }

  function generateMapper(packages, classNames, methodName, responseMode) {
    const lines = [
      "package " + packages.mapper + ";",
      "",
      "import " + packages.dto + "." + classNames.requestDto + ";",
    ];

    if (responseMode === "list" || responseMode === "single") {
      lines.push("import " + packages.dto + "." + classNames.responseDto + ";");
    }
    if (responseMode === "list") {
      lines.push("import java.util.List;");
    }
    lines.push("import org.apache.ibatis.annotations.Mapper;");
    lines.push(
      "",
      "@Mapper",
      "public interface " + classNames.mapper + " {",
      "    " + getReturnType(responseMode, classNames) + " " + methodName + "(" + classNames.requestDto + " requestDto);",
      "}",
      ""
    );

    return lines.join("\n");
  }

  function buildSkeletonMapperXml(namespace, methodName, action, responseMode, requestDtoFqn, responseDtoFqn) {
    const statementAttrs = {
      id: methodName,
      parameterType: requestDtoFqn,
    };

    if (action === "select" && (responseMode === "list" || responseMode === "single")) {
      statementAttrs.resultType = responseDtoFqn;
    }

    return [
      '<?xml version="1.0" encoding="UTF-8"?>',
      MYBATIS_DOCTYPE,
      '<mapper namespace="' + namespace + '">',
      "  <" + action + buildAttributeString(statementAttrs, ["id", "parameterType", "resultType"]) + ">",
      "    -- TODO: SQL을 붙여 넣어 주세요.",
      "  </" + action + ">",
      "</mapper>",
      "",
    ].join("\n");
  }

  function ensureXmlDeclaration(source) {
    const withoutBom = String(source || "").replace(/^\uFEFF/, "");
    if (/^\s*<\?xml\b/i.test(withoutBom)) {
      return withoutBom.replace(/^\s*<\?xml\b[^>]*\?>/i, '<?xml version="1.0" encoding="UTF-8"?>');
    }
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + withoutBom.trimStart();
  }

  function replaceDoctype(source) {
    const regex = /<!DOCTYPE\s+(sqlMap|mapper)[\s\S]*?>/i;
    if (regex.test(source)) {
      return source.replace(regex, MYBATIS_DOCTYPE);
    }
    return source.replace(/^\s*<\?xml\b[^>]*\?>/i, function (match) {
      return match + "\n" + MYBATIS_DOCTYPE;
    });
  }

  function wrapStatementsWithMapper(source, namespace) {
    const trimmed = String(source || "").trim();
    if (!trimmed) {
      return '<mapper namespace="' + namespace + '"></mapper>';
    }
    if (/<\s*(sqlMap|mapper)\b/i.test(trimmed)) {
      return trimmed;
    }
    return '<mapper namespace="' + namespace + '">\n' + trimmed + "\n</mapper>";
  }

  function quoteLiteral(value) {
    if (value == null || value === "") {
      return "''";
    }
    if (/^-?\d+(\.\d+)?$/.test(String(value))) {
      return String(value);
    }
    if (/^(true|false|null)$/i.test(String(value))) {
      return String(value).toLowerCase();
    }
    return "'" + String(value).replace(/'/g, "\\'") + "'";
  }

  function buildIfTest(tagName, attrs) {
    const property = attrs.property;

    if (tagName === "isParameterPresent") {
      return "_parameter != null";
    }
    if (tagName === "isNotParameterPresent") {
      return "_parameter == null";
    }

    if (!property) {
      return "";
    }

    switch (tagName) {
      case "isNotNull":
        return property + " != null";
      case "isNull":
        return property + " == null";
      case "isNotEmpty":
        return property + " != null and " + property + " != ''";
      case "isEmpty":
        return property + " == null or " + property + " == ''";
      case "isEqual":
        return property + " == " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isNotEqual":
        return property + " != " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isGreaterThan":
        return property + " > " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isGreaterEqual":
        return property + " >= " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isLessThan":
        return property + " < " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      case "isLessEqual":
        return property + " <= " + (attrs.compareProperty || quoteLiteral(attrs.compareValue));
      default:
        return "";
    }
  }

  function convertRootMapper(source, namespace) {
    const sqlMapMatch = source.match(/<sqlMap\b([^>]*)>/i);
    if (sqlMapMatch) {
      return source
        .replace(/<sqlMap\b([^>]*)>/i, '<mapper namespace="' + namespace + '">')
        .replace(/<\/sqlMap>/gi, "</mapper>");
    }

    const mapperMatch = source.match(/<mapper\b([^>]*)>/i);
    if (mapperMatch) {
      return source.replace(/<mapper\b([^>]*)>/i, '<mapper namespace="' + namespace + '">');
    }

    return source;
  }

  function replaceCommonAttributes(source) {
    return source
      .replace(/\bparameterCalss\s*=/gi, "parameterType=")
      .replace(/\bparameterClass\s*=/gi, "parameterType=")
      .replace(/\bresultClass\s*=/gi, "resultType=")
      .replace(/\s+remapResults\s*=\s*(["']).*?\1/gi, "");
  }

  function replacePlaceholders(source) {
    return source
      .replace(/#\[\]#/g, "#{item}")
      .replace(/\$\[\]\$/g, "${item}")
      .replace(/#([^#\r\n]+?)#/g, function (_match, inner) {
        return "#{" + inner.trim() + "}";
      })
      .replace(/\$([^$\r\n]+?)\$/g, function (_match, inner) {
        return "${" + inner.trim() + "}";
      });
  }

  function buildFieldNameMap(fields) {
    const fieldMap = {};

    (fields || []).forEach(function (field) {
      const variants = unique([
        field.rawName,
        String(field.rawName || "").toUpperCase(),
        field.javaName,
        toPascalCase(field.rawName),
      ].filter(Boolean));

      variants.forEach(function (variant) {
        fieldMap[String(variant).trim()] = field.javaName;
      });
    });

    return fieldMap;
  }

  function applyFieldNameMappings(source, fieldNameMap) {
    let converted = source;

    converted = converted.replace(/([#$])\{([^}]+)\}/g, function (_full, prefix, inner) {
      const trimmed = inner.trim();
      const mapped = fieldNameMap[trimmed] || trimmed;
      return prefix + "{" + mapped + "}";
    });

    converted = converted.replace(
      /\b(property|compareProperty)\s*=\s*(['"])(.*?)\2/gi,
      function (_full, attrName, quote, value) {
        const mapped = fieldNameMap[String(value).trim()] || value;
        return attrName + "=" + quote + mapped + quote;
      }
    );

    return converted;
  }

  function convertIterate(source) {
    return source
      .replace(/<\s*iterate\b([^>]*)>/gi, function (_full, attrText) {
        const attrs = parseAttributes(attrText || "");
        const collection = attrs.property || "items";
        const open = attrs.open ? ' open="' + attrs.open + '"' : "";
        const close = attrs.close ? ' close="' + attrs.close + '"' : "";
        const separator = attrs.conjunction ? ' separator="' + attrs.conjunction + '"' : "";
        return '<foreach collection="' + collection + '" item="item"' + open + close + separator + ">";
      })
      .replace(/<\/iterate>/gi, "</foreach>");
  }

  function convertDynamicTags(source, warnings) {
    let converted = source.replace(
      /<\s*(dynamic|isNotNull|isNull|isNotEmpty|isEmpty|isEqual|isNotEqual|isGreaterThan|isGreaterEqual|isLessThan|isLessEqual|isParameterPresent|isNotParameterPresent)\b([^>]*)>/gi,
      function (fullMatch, tagName, attrText) {
        const attrs = parseAttributes(attrText || "");

        if (tagName === "dynamic") {
          const prefix = attrs.prepend ? ' prefix="' + attrs.prepend + '"' : "";
          const prefixOverrides = attrs.prepend ? ' prefixOverrides="AND |OR "' : "";
          return "<trim" + prefix + prefixOverrides + ">";
        }

        const test = buildIfTest(tagName, attrs);
        if (!test) {
          warnings.push(tagName + " 태그의 조건식을 완전히 해석하지 못했습니다.");
          return fullMatch;
        }

        const prepend = attrs.prepend ? attrs.prepend + " " : "";
        return '<if test="' + test + '">' + prepend;
      }
    );

    converted = converted.replace(/<\/dynamic>/gi, "</trim>");
    converted = converted.replace(
      /<\/(isNotNull|isNull|isNotEmpty|isEmpty|isEqual|isNotEqual|isGreaterThan|isGreaterEqual|isLessThan|isLessEqual|isParameterPresent|isNotParameterPresent)>/gi,
      "</if>"
    );

    return converted;
  }

  function updateStatementAttributes(source, options, warnings) {
    const statementRegex = /<\s*(select|insert|update|delete)\b([^>]*)>/gi;
    const statements = source.match(statementRegex) || [];

    return source.replace(statementRegex, function (_full, tagName, attrText) {
      const attrs = parseAttributes(attrText || "");
      const originalId = attrs.id || "";

      if (statements.length === 1) {
        attrs.id = options.methodName || originalId || options.defaultStatementId;
      } else {
        attrs.id = originalId || options.defaultStatementId;
        if (options.methodName && originalId && originalId !== options.methodName) {
          warnings.push("SQL에 여러 statement가 있어 id는 원본 값을 유지했습니다.");
        }
      }

      attrs.parameterType = options.requestDtoFqn;

      if (tagName.toLowerCase() === "select") {
        attrs.resultType = options.responseDtoFqn;
      } else {
        delete attrs.resultType;
      }

      return "<" + tagName + buildAttributeString(attrs, [
        "id",
        "parameterType",
        "resultType",
        "fetchSize",
        "statementType",
        "useCache",
      ]) + ">";
    });
  }

  function findRemainingLegacyTags(source) {
    const tags = [];
    source.replace(/<\s*\/?\s*([A-Za-z][\w.-]*)\b/g, function (_full, tagName) {
      if (/^is[A-Z]/.test(tagName) || tagName === "dynamic" || tagName === "iterate") {
        if (tags.indexOf(tagName) === -1) {
          tags.push(tagName);
        }
      }
      return _full;
    });
    return tags.sort();
  }

  function convertIbatisToMybatis(xmlSource, options, warnings) {
    if (isBlank(xmlSource)) {
      warnings.push("SQL XML이 없어 Mapper.xml은 TODO 템플릿으로 생성했습니다.");
      return buildSkeletonMapperXml(
        options.namespace,
        options.methodName,
        options.action,
        options.responseMode,
        options.requestDtoFqn,
        options.responseDtoFqn
      );
    }

    let converted = wrapStatementsWithMapper(xmlSource, options.namespace);
    converted = ensureXmlDeclaration(converted);
    converted = replaceDoctype(converted);
    converted = convertRootMapper(converted, options.namespace);
    converted = replaceCommonAttributes(converted);
    converted = replacePlaceholders(converted);
    converted = applyFieldNameMappings(converted, options.fieldNameMap || {});
    converted = convertIterate(converted);
    converted = convertDynamicTags(converted, warnings);
    converted = updateStatementAttributes(converted, options, warnings);

    const legacyTags = findRemainingLegacyTags(converted);
    if (legacyTags.length > 0) {
      warnings.push("자동 변환 후에도 남은 레거시 태그: " + legacyTags.join(", "));
    }

    return converted.replace(/\r\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
  }

  function generateController(packages, classNames, methodName, responseMode, endpointPath, featureClassName) {
    const lines = [
      "package " + packages.controller + ";",
      "",
      "import " + packages.dto + "." + classNames.requestDto + ";",
    ];

    if (responseMode === "list" || responseMode === "single") {
      lines.push("import " + packages.dto + "." + classNames.responseDto + ";");
    }

    lines.push(
      "import " + packages.service + "." + classNames.service + ";",
      "import io.swagger.v3.oas.annotations.Operation;",
      "import io.swagger.v3.oas.annotations.tags.Tag;",
      "import lombok.RequiredArgsConstructor;",
      "import org.springframework.http.ResponseEntity;",
      "import org.springframework.web.bind.annotation.PostMapping;",
      "import org.springframework.web.bind.annotation.RequestBody;",
      "import org.springframework.web.bind.annotation.RequestMapping;",
      "import org.springframework.web.bind.annotation.RestController;"
    );

    if (responseMode === "list") {
      lines.push("import java.util.List;");
    }

    const responseType = responseMode === "void"
      ? "Void"
      : getReturnType(responseMode, classNames);

    const methodPath = "/" + toKebabCase(methodName);
    const serviceField = toCamelCase(classNames.service);
    const operationSummary = featureClassName + " " + methodName + " API";
    const requestMapping = endpointPath || "/api/" + toKebabCase(featureClassName);

    const methodBody = [];
    if (responseMode === "void") {
      methodBody.push("        " + serviceField + "." + methodName + "(requestDto);");
      methodBody.push("        return ResponseEntity.ok().build();");
    } else {
      methodBody.push("        return ResponseEntity.ok(" + serviceField + "." + methodName + "(requestDto));");
    }

    lines.push(
      "",
      '@Tag(name = "' + featureClassName + '")',
      "@RestController",
      "@RequiredArgsConstructor",
      '@RequestMapping("' + requestMapping + '")',
      "public class " + classNames.controller + " {",
      "    private final " + classNames.service + " " + serviceField + ";",
      "",
      '    @Operation(summary = "' + operationSummary + '")',
      '    @PostMapping("' + methodPath + '")',
      "    public ResponseEntity<" + responseType + "> " + methodName + "(@RequestBody " + classNames.requestDto + " requestDto) {",
      methodBody.join("\n"),
      "    }",
      "}",
      ""
    );

    return lines.join("\n");
  }

  function buildExampleValue(javaType, fieldName) {
    if (javaType === "Integer" || javaType === "Long" || javaType === "Double") {
      return 0;
    }
    if (javaType === "BigDecimal") {
      return 0;
    }
    if (javaType === "Boolean") {
      return false;
    }
    if (javaType === "LocalDate") {
      return "2026-01-01";
    }
    if (javaType === "LocalDateTime") {
      return "2026-01-01T00:00:00";
    }
    if (/yn$/i.test(fieldName)) {
      return "Y";
    }
    return "";
  }

  function buildExampleJson(fields) {
    const payload = {};
    fields.forEach(function (field) {
      payload[field.javaName] = buildExampleValue(field.javaType, field.javaName);
    });
    return JSON.stringify(payload, null, 2) + "\n";
  }

  function generateSummary(featureClassName, packages, methodName, action, responseMode, requestFields, responseFields, sqlMeta) {
    return [
      "도메인명: " + featureClassName,
      "메서드명: " + methodName,
      "액션: " + action,
      "응답형태: " + responseMode,
      "요청 필드 수: " + requestFields.length,
      "응답 필드 수: " + responseFields.length,
      "SQL statement 수: " + ((sqlMeta && sqlMeta.statements && sqlMeta.statements.length) || 0),
      "DTO 패키지: " + packages.dto,
      "Service 패키지: " + packages.service,
      "Mapper 패키지: " + packages.mapper,
      "Controller 패키지: " + packages.controller,
      "",
    ].join("\n");
  }

  function generateBackendArtifacts(input, options) {
    const warnings = [];
    const mergedOptions = {
      basePackage: "com.example.demo",
      featureName: "",
      endpointPath: "",
      action: "auto",
      responseMode: "auto",
      dateType: "String",
      requestFieldsText: "",
      responseFieldsText: "",
      serviceMethodText: "",
      sqlXmlText: "",
    };

    Object.keys(options || {}).forEach(function (key) {
      mergedOptions[key] = options[key];
    });

    if (input && typeof input === "object") {
      Object.keys(input).forEach(function (key) {
        mergedOptions[key] = input[key];
      });
    }

    const requestFields = parseFieldText(mergedOptions.requestFieldsText, mergedOptions, warnings, "요청값");
    const responseFields = parseFieldText(mergedOptions.responseFieldsText, mergedOptions, warnings, "응답값");
    const serviceMeta = parseServiceMethod(mergedOptions.serviceMethodText);
    const sqlMeta = parseSqlMeta(mergedOptions.sqlXmlText);

    const featureClassName = guessFeatureName(mergedOptions.featureName, serviceMeta, sqlMeta);
    const classNames = buildClassNames(featureClassName);
    const packages = buildPackages(mergedOptions.basePackage, featureClassName);
    const action = inferAction(serviceMeta.methodName, sqlMeta, mergedOptions.action);
    const responseMode = inferResponseMode(action, mergedOptions.responseMode, serviceMeta);
    const methodName = guessMethodName(serviceMeta, sqlMeta, featureClassName, action, responseMode);
    const fieldNameMap = buildFieldNameMap(requestFields);

    const mapperXml = convertIbatisToMybatis(mergedOptions.sqlXmlText, {
      namespace: packages.mapper + "." + classNames.mapper,
      methodName: methodName,
      defaultStatementId: methodName,
      action: action,
      responseMode: responseMode,
      fieldNameMap: fieldNameMap,
      requestDtoFqn: packages.dto + "." + classNames.requestDto,
      responseDtoFqn: packages.dto + "." + classNames.responseDto,
    }, warnings);

    if (requestFields.length === 0) {
      warnings.push("요청 DTO 필드가 비어 있습니다. 필요하면 수동으로 추가해 주세요.");
    }
    if (responseMode !== "int" && responseMode !== "void" && responseFields.length === 0) {
      warnings.push("응답 DTO 필드가 비어 있습니다. 필요하면 수동으로 추가해 주세요.");
    }
    if (!serviceMeta.methodName) {
      warnings.push("서비스 메서드를 완전히 해석하지 못해 메서드명을 자동 생성했습니다.");
    }

    return {
      meta: {
        featureClassName: featureClassName,
        methodName: methodName,
        action: action,
        responseMode: responseMode,
      },
      warnings: unique(warnings),
      artifacts: {
        summary: generateSummary(featureClassName, packages, methodName, action, responseMode, requestFields, responseFields, sqlMeta),
        requestDto: generateDto(packages.dto, classNames.requestDto, requestFields),
        responseDto: generateDto(packages.dto, classNames.responseDto, responseFields),
        service: generateService(packages, classNames, methodName, responseMode),
        serviceImpl: generateServiceImpl(packages, classNames, methodName, responseMode, action),
        mapper: generateMapper(packages, classNames, methodName, responseMode),
        mapperXml: mapperXml,
        controller: generateController(packages, classNames, methodName, responseMode, mergedOptions.endpointPath, featureClassName),
        requestExampleJson: buildExampleJson(requestFields),
      },
    };
  }

  return {
    generateBackendArtifacts: generateBackendArtifacts,
  };
});
