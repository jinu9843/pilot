# Nexacro -> Spring Boot 백엔드 생성기

오프라인에서 동작하는 단일 HTML/JS 도구입니다.  
회사 환경에서 복붙만으로 Spring Boot 백엔드 초안을 만들 수 있게 구성했습니다.

## 실행

- `open_generator.bat` 더블클릭
- 또는 `index.html` 브라우저로 직접 열기

## 입력

화면에는 아래 4개 입력 칸이 있습니다.

1. 넥사크로 요청값
2. 넥사크로 응답값
3. 넥스코어 서비스 메서드
4. 기존 SQL XML

## 출력

아래 결과를 탭으로 생성합니다.

- 요약
- RequestDto
- ResponseDto
- Service
- ServiceImpl
- Mapper
- Mapper.xml
- Controller
- Swagger JSON

## 지원 규칙

### 필드 입력 해석

아래 같은 형식을 해석합니다.

- `USER_ID`
- `USER_ID String`
- `private String userId;`
- `"userId": "sunshine"`
- `<Column id="USER_ID" type="STRING" />`

### SQL XML 변환

- `sqlMap` -> `mapper`
- `parameterClass`, `parameterCalss` -> `parameterType`
- `resultClass` -> `resultType`
- `remapResults` 제거
- `#param#` -> `#{param}`
- `$param$` -> `${param}`
- `dynamic` -> `trim`
- `iterate` -> `foreach`
- `isNotNull`, `isNull`, `isNotEmpty`, `isEmpty`
- `isEqual`, `isNotEqual`
- `isGreaterThan`, `isGreaterEqual`, `isLessThan`, `isLessEqual`
- `isParameterPresent`, `isNotParameterPresent`

## 주의

- 이 도구는 규칙 기반 초안 생성기입니다.
- 생성된 `ServiceImpl` 과 `Mapper.xml` 은 바로 쓰기 전에 비즈니스 로직과 SQL 조건을 꼭 확인해야 합니다.
- 해석이 애매한 부분은 화면 아래 `확인 메시지` 영역에 표시됩니다.
